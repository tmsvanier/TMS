
package factorialproject;

public class TestFactorial {


    public static void main(String[] args) {
        System.out.println("Factorial of 6 is " + fact(6));
        System.out.println("Factorial of 10 is " + fact(10));

        }
    
    public static int fact(int num)
        {

        if(num==0)    return 1;
        else return num*fact(num-1);
        }

    
}
