 
package billingproject;
import java.io.*;
import java.util.Scanner;
public class TestBillingProgram   {

static Scanner console = new Scanner(System.in);
    public static void main(String[] args) throws FileNotFoundException
    {
    PrintWriter outFile = new PrintWriter("Billing.out");

    double Product_Price;
    int Product_Qty;
    
    System.out.println("The billing system built with object oriented programming (OOP)");
    
    System.out.print("Enter your Product's Price: ");
    Product_Price = console.nextDouble();
    
    System.out.print("Enter your Product's Quantity: ");
    Product_Qty = console.nextInt();   
    
    Billing yourBilling = new Billing();
    yourBilling.setPrd_Price(Product_Price);
    yourBilling.setPrd_Qty(Product_Qty);
                   
    System.out.println("After setting yourBilling object, ");
    yourBilling.printBillingInfo();
    
    System.out.println("\t\t\t The total of Billing of yourBilling is " + yourBilling.CalculateBilling() + "$");
    outFile.println("yourBilling    " + yourBilling.getPrd_Price() + "  " + yourBilling.getPrd_Qty() + "  " + Billing.Fed_Tax + " " + Billing.Prv_Tax + " TotalBill:" + yourBilling.CalculateBilling());

    
    
    Billing myBilling1 = new Billing();
    myBilling1.setPrd_Price(29.99);
    myBilling1.setPrd_Qty(7);
    
    System.out.println("After setting myBilling1 object, ");
    myBilling1.printBillingInfo();
    
    System.out.println("\t\t\t The total of Billing of myBilling1 is " + 
            myBilling1.CalculateBilling() + "$");
    outFile.println("myBilling1    " + myBilling1.getPrd_Price() + "  " + myBilling1.getPrd_Qty() + "  " + Billing.Fed_Tax + " " + Billing.Prv_Tax + " TotalBill:" + myBilling1.CalculateBilling());

    
    Billing myBilling2 = new Billing(49.99, 3);
    System.out.println("After setting myBilling2 object, ");
    myBilling2.printBillingInfo();
    
    System.out.println("\t\t\t The total of Billing of myBilling2 is " + 
            myBilling2.CalculateBilling() + "$");

outFile.println("myBilling2    " + myBilling2.getPrd_Price() + "  " + myBilling2.getPrd_Qty() + "  " + Billing.Fed_Tax + " " + Billing.Prv_Tax + " TotalBill:" + myBilling2.CalculateBilling());        
    
    System.out.println("After setting myBilling2 object, ");
    myBilling2.setPrd_Price(89.99);
    myBilling2.setPrd_Qty(12);
    myBilling2.printBillingInfo();
    
    System.out.println("\t\t\t The total of Billing of myBilling2 is " + 
            myBilling2.CalculateBilling() + "$");
    
    outFile.println("myBilling2    " + myBilling2.getPrd_Price() + "  " + myBilling2.getPrd_Qty() + "  " + Billing.Fed_Tax + " " + Billing.Prv_Tax + " TotalBill:" + myBilling2.CalculateBilling());    
        
    
    System.out.println("\nTo access the data members of myBIlling2 Object, ");
    System.out.println("Product price: " + myBilling2.getPrd_Price());
    System.out.println("Product quantity: " + myBilling2.getPrd_Qty());
    System.out.println("Fed Tax: " + Billing.Fed_Tax);
    System.out.println("Fed Tax: " + Billing.Prv_Tax);
    
    
    System.out.println("\nThe total of billing of yourBilling, myBilling1, myBilling2 objects is " + (yourBilling.CalculateBilling() + 
            myBilling1.CalculateBilling() + myBilling2.CalculateBilling()) + "$");
    
    Billing myBilling3= new Billing(yourBilling);
    System.out.println("\nAfter setting myBilling3 object, ");
 
    myBilling3.printBillingInfo();
    
    System.out.println("\t\t\t The total of Billing of myBilling3 is " + 
            myBilling3.CalculateBilling() + "$");    
    
    outFile.println("myBilling3    " + myBilling3.getPrd_Price() + "  " + myBilling3.getPrd_Qty() + "  " + Billing.Fed_Tax + " " + Billing.Prv_Tax + " TotalBill:" + myBilling3.CalculateBilling());    

    System.out.println("\nRemember, yourBilling object, ");
    yourBilling.printBillingInfo();
    System.out.println("\t\t\t The total of Billing of yourBilling is " + 
            yourBilling.CalculateBilling() + "$");  
    
    
    
    
    
    Billing RecordBilling1 = new Billing();
    Billing RecordBilling2 = new Billing();
    Billing RecordBilling3 = new Billing();
    Scanner inFile = new Scanner(new FileReader("Billing.in"));


    System.out.println("\nReading Book.in records from an input file (Simulate Oracle Table Reading");

    Product_Price = inFile.nextDouble();
    Product_Qty = inFile.nextInt();
    double taxFed = inFile.nextDouble();
    double taxPrv = inFile.nextDouble();       

    RecordBilling1.setPrd_Price(Product_Price);
    RecordBilling1.setPrd_Qty(Product_Qty);


    System.out.println("\nRecord N1, Prod Price " + RecordBilling1.getPrd_Price() + "$, Prod Qty " + RecordBilling1.getPrd_Qty() + ", Fed Tax " + Billing.Fed_Tax + ", Prv Tax " + Billing.Prv_Tax);

    System.out.println("After setting RecordBilling1 object, ");
    RecordBilling1.printBillingInfo();
    
    System.out.println("\t\t\t The total of Billing of RecordBilling1 is " +  RecordBilling1.CalculateBilling() + "$");
    outFile.println("RecordBilling1    " + RecordBilling1.getPrd_Price() + "  " + RecordBilling1.getPrd_Qty() + "  " + Billing.Fed_Tax + " " + Billing.Prv_Tax + " TotalBill:" + RecordBilling1.CalculateBilling());        
    
    

    
    Product_Price = inFile.nextDouble();
    Product_Qty = inFile.nextInt();
    taxFed = inFile.nextDouble();
    taxPrv = inFile.nextDouble();       

    RecordBilling2.setPrd_Price(Product_Price);
    RecordBilling2.setPrd_Qty(Product_Qty);


    System.out.println("\nRecord N2, Prod Price " + RecordBilling2.getPrd_Price() + "$, Prod Qty " + RecordBilling2.getPrd_Qty() + ", Fed Tax " + Billing.Fed_Tax + ", Prv Tax " + Billing.Prv_Tax);

    System.out.println("After setting RecordBilling2 object, ");
    RecordBilling2.printBillingInfo();
    
    System.out.println("\t\t\t The total of Billing of RecordBilling2 is " +  RecordBilling2.CalculateBilling() + "$");
    outFile.println("RecordBilling2    " + RecordBilling2.getPrd_Price() + "  " + RecordBilling2.getPrd_Qty() + "  " + Billing.Fed_Tax + " " + Billing.Prv_Tax + " TotalBill:" + RecordBilling2.CalculateBilling());        
        
    
    
    Product_Price = inFile.nextDouble();
    Product_Qty = inFile.nextInt();
    taxFed = inFile.nextDouble();
    taxPrv = inFile.nextDouble();       

    RecordBilling3.setPrd_Price(Product_Price);
    RecordBilling3.setPrd_Qty(Product_Qty);


    System.out.println("\nRecord N3, Prod Price " + RecordBilling1.getPrd_Price() + "$, Prod Qty " + RecordBilling3.getPrd_Qty() + ", Fed Tax " + Billing.Fed_Tax + ", Prv Tax " + Billing.Prv_Tax);

    System.out.println("After setting RecordBilling3 object, ");
    RecordBilling3.printBillingInfo();
    
    System.out.println("\t\t\t The total of Billing of RecordBilling3 is " +  RecordBilling3.CalculateBilling() + "$");
    outFile.println("RecordBilling3    " + RecordBilling3.getPrd_Price() + "  " + RecordBilling3.getPrd_Qty() + "  " + Billing.Fed_Tax + " " + Billing.Prv_Tax + " TotalBill:" + RecordBilling3.CalculateBilling());        
        

    System.out.println("\nThe total of billing of RecordBilling1, RecordBilling2,RecordBilling3 objects is " + (RecordBilling1.CalculateBilling() + 
            RecordBilling2.CalculateBilling() + RecordBilling3.CalculateBilling()) + "$");
    
    
        Billing myBilling4 = new Billing(RecordBilling2);
    System.out.println("\nAfter setting myBilling4 object, ");
 
    myBilling4.printBillingInfo();
    
    System.out.println("\t\t\t The total of Billing of myBilling4 is " + 
            myBilling4.CalculateBilling() + "$");    
    
    
    Billing myBilling5= new Billing();
    myBilling5.doSumBilling(RecordBilling2, RecordBilling3);
    System.out.println("\nTesting the method doSumBilling, myBilling5 object, ");
    System.out.println("After calling the method doSumBilling, myBilling5 object " + myBilling5.getPrd_Price() + "  " + myBilling5.getPrd_Qty() + " " + Billing.Fed_Tax + " " + Billing.Prv_Tax + "  TotalBill:" + myBilling5.CalculateBilling());
    
    inFile.close();
    outFile.close();
    }
    
     
    
}
