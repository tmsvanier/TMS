 
package billingproject;
 
public class Billing {
    private double prd_Price;
    private int prd_Qty;
    public static double Fed_Tax = 0.075;
    public static double Prv_Tax = 0.06;
    
    public Billing()
    {
        prd_Price=0;
        prd_Qty=0;
    } 
    public Billing(double prd_Price_t, int prd_Qty_t)
    {
        prd_Price=prd_Price_t;
        prd_Qty=prd_Qty_t;
    }
     public Billing(Billing vBilling)
    {
        prd_Price = vBilling.prd_Price;
        prd_Qty = vBilling.prd_Qty;
    }
    
    public void setPrd_Price(double prd_Price_t2)
    {
        prd_Price=prd_Price_t2;
    }
    
    public void setPrd_Qty(int prd_Qty_t2)
    {
        prd_Qty=prd_Qty_t2;
    }    
    
    public double getPrd_Price()
    {
        return prd_Price;
    }
    
    public int getPrd_Qty()
    {
        return prd_Qty;
    }
        
    
    public double CalculateBilling()  
    {
        double T_Billing;
        T_Billing = (prd_Price * prd_Qty) + (prd_Price * prd_Qty) * Fed_Tax + (prd_Price*prd_Qty) * Prv_Tax;
        return T_Billing;
    }
    
    public void printBillingInfo()
    {
        System.out.println("The billing information is: " +  " Price:" + prd_Price + "$ // Qty:" + prd_Qty + " // FedT: " + Fed_Tax + " // PrvT:" + Prv_Tax);
    }
    
    public Billing doSumBilling(Billing otherBilling1, Billing otherBilling2) 
    {
        Billing SumBilling = new Billing();
        prd_Price = otherBilling1.prd_Price + otherBilling2.prd_Price;
        prd_Qty = otherBilling1.prd_Qty + otherBilling2.prd_Qty;
        return SumBilling;
    }
    
    
   
}
    