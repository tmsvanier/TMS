 
package courseproject;

 
public class TestCourseProgram {

 
    public static void main(String[] args) {

        Course myCourse1 = new Course();
        Course myCourse2 = new Course();
        Course myCourse3 = new Course();
        Course myCourse4 = new Course();
        Course myCourse5 = new Course();
        Course myCourse6 = new Course();
        Course myCourse7 = new Course();
        
        System.out.println("Line 2: After setting, myCourse1:");
        myCourse1.setValue("MIS XXX", "Understanding Computers", 3, 200);
        myCourse1.printCourseInfo();
 
        System.out.println("\nRe-Assigning values to object referenced by myCourse1 reference  object of type Course class");
        System.out.println("After setting, myCourse1:");
        myCourse1.setValue("MIS 101", "Intro.to info. Systems", 3, 140);
        myCourse1.printCourseInfo();
        
        System.out.println("\nAfter setting, myCourse2:");
        myCourse2.setValue("MIS 301", "Systems Analysis", 3, 35);
        myCourse2.printCourseInfo();    
        
        System.out.println("\nAfter setting, myCourse3:");
        myCourse3.setValue("MIS 441", "Database Management", 3, 12);
        myCourse3.printCourseInfo();  
        
        System.out.println("\nAfter setting, myCourse4:");
        myCourse4.setValue("MIS 155", "Programming in C++", 3, 90);
        myCourse4.printCourseInfo();  
        
        System.out.println("\nAfter setting, myCourse5:");
        myCourse5.setValue("MIS 451", "Web-Based Systems", 3, 30);
        myCourse5.printCourseInfo();          
        
        System.out.println("\nAfter setting, myCourse6:");
        myCourse6.setValue("MIS 551", "Advanced WEB", 3, 30);
        myCourse6.printCourseInfo();  
        
        System.out.println("\nAfter setting, myCourse7:");
        myCourse7.setValue("MIS 651", "Advanced JAVA", 3, 30);
        myCourse7.printCourseInfo();          
        
        System.out.println("\nLine 15: Calculate the Total  fees for myCourse7:");
        System.out.println("The Total Fees corresponding to Advanced JAVA is " + myCourse7.CalculateTotalFees());
       
    }
    
}
