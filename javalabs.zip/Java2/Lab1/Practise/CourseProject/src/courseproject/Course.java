 
package courseproject;

 
public class Course {
   private String course_no;
   private String course_name;
   private int max_enrl;
   public static int credits;
   
   
   public void setValue(String wcourse_no, String wcourse_name, int wcredits, int wmax_enrl)
   {
       course_no=wcourse_no;
       course_name=wcourse_name;
       credits=wcredits;
       max_enrl=wmax_enrl;
   }
   
   public double CalculateTotalFees()
   {
       double totalfees = max_enrl * 250;
       return totalfees;
   }
   
   public void printCourseInfo()
   {
        System.out.println("The course information is: " + course_no + "//"
                + course_name + "//" + credits + "//" + max_enrl);       
   }
}
