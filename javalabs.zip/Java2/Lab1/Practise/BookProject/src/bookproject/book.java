 
package bookproject;

 
public class book {
    private int b_id;
    private String b_author;
    private String b_title;
    private String b_isbn;
    private String b_type;
    private double b_price;
    private int b_pid;
    
    public book()
    {
        b_id=0;
        b_author=""; 
        b_title="";
        b_isbn="";
        b_type="";
        b_price=0.0;
        b_pid=0;
    }
    
    public book(int b_idT, String b_authorT, String b_titleT, String b_isbnT, String b_typeT, double b_priceT, int b_pidT)
    {
        b_id=b_idT;
        b_author=b_authorT; 
        b_title=b_titleT;
        b_isbn=b_isbnT;
        b_type=b_typeT; 
        b_price=b_priceT;        
        b_pid=b_pidT;                       
    }    
    
    public void setBook_id(int b_idT)
    {
        b_id=b_idT;
    }
    public void setB_Author(String b_authorT)
    {
        b_author=b_authorT;
    }    
    public void setB_Title(String b_titleT)
    {
        b_title=b_titleT;
    }
    public void setB_Isbn(String b_isbnT)
    {
        b_isbn=b_isbnT;
    }
    public void setB_Type(String b_typeT)
    {
        b_type=b_typeT;
    }        
    public void setB_Price(double b_priceT)
    {
        b_price=b_priceT;
    }
    public void setB_p_id(int b_pidT)
    {
        b_pid=b_pidT;
    }    
    
    
    public int getBook_id()
    {
        return b_id;
    }
    public String getB_Author()
    {
        return b_author;
    }
    public String getB_Title()
    {
        return b_title;
    }
    public String getB_Isbn()
    {
        return b_isbn;
    }
    public String getB_Type()
    {
        return b_type;
    }
    public double getB_Price()
    {
        return b_price;
    }
    public int getB_p_id()
    {
        return b_pid;
    }    
    
    public String toString()
    {
        return ("The Book Information is: " + b_id + "//"+ b_author + "//" + b_title + "//" + b_isbn + "//" + b_type+ "//" + b_price+ "//" + b_pid);
    }   
    
    public double calculate_Price_Euro(double b_price)
    {
        double priceEuro;
        priceEuro = b_price*0.7;
        return priceEuro;
    }
}
