 
package bookproject;
import java.io.*;
import java.util.Scanner;
public class TestBookProject {

 
    public static void main(String[] args) throws FileNotFoundException
    {
        Scanner console = new Scanner(System.in);
        
        
        int u_b_id, u_b_pid;
        String u_b_author, u_b_title, u_b_isbn, u_b_type;
        double u_b_price;
        
        book myBook1 = new book();
        book yourBook1 = new book(18, "Jane Brow", "Introduction to ASP","654321987","BG", 59.99, 4);
        book yourBook2 = new book(30, "Martin Bilmeau", "Programming in C++","654987321","EX", 119.99, 5);
        book yourBook3 = new book(42, "Pamela Yale", "Programming in C sharp","654987321","SR", 299.99, 3);
    
        System.out.println("myBook1 Object: \n" + myBook1);
        System.out.println("yourBook1 Object: \n" + yourBook1);
        System.out.println("yourBook2 Object: \n" + yourBook2);
        System.out.println("yourBook3 Object: \n" + yourBook3);
        
        System.out.print("\n\nEnter Book ID: ");
        u_b_id = Integer.parseInt(console.nextLine());
        
        System.out.print("Enter Book Author: ");
        u_b_author = console.nextLine();
        
        System.out.print("Enter Book Title: ");
        u_b_title = console.nextLine();
        
        System.out.print("Enter Book ISBN: ");
        u_b_isbn = console.nextLine();
        
        System.out.print("Enter Book Type: ");
        u_b_type = console.nextLine();
        
        System.out.print("Enter Book Price: ");
        u_b_price = console.nextDouble();   
        
        System.out.print("Enter Publisher ID: ");
        u_b_pid = console.nextInt();  
        
        System.out.println("\nThe new yourBook2 Object: ");
        yourBook2.setBook_id(u_b_id);
        yourBook2.setB_Author(u_b_author);
        yourBook2.setB_Title(u_b_title);
        yourBook2.setB_Isbn(u_b_isbn);
        yourBook2.setB_Type(u_b_type);
        yourBook2.setB_Price(u_b_price);
        yourBook2.setB_p_id(u_b_pid);
        System.out.println(yourBook2);
        
        System.out.println("\nThe price in Euro related to yourBook2 Object: " + yourBook2.calculate_Price_Euro(u_b_price));
        
 
        book RecordBook1 = new book();
        book RecordBook2 = new book();
        book RecordBook3 = new book();
        book RecordBook4 = new book();
        book RecordBook5 = new book();
        book RecordBook6 = new book();
        
        Scanner inFile = new Scanner(new FileReader("Book.in"));
        inFile.useDelimiter(":");
        
        System.out.println("\nReading Book.in records from an input file (Simulate Oracle Table Reading");
        
            u_b_id = inFile.nextInt();
            u_b_author = inFile.next();
            u_b_title = inFile.next();
            u_b_isbn = inFile.next();
            u_b_type = inFile.next();
            u_b_price = inFile.nextDouble();
            u_b_pid = inFile.nextInt();  
            
            RecordBook1.setBook_id(u_b_id);
            RecordBook1.setB_Author(u_b_author);
            RecordBook1.setB_Title(u_b_title);
            RecordBook1.setB_Isbn(u_b_isbn);
            RecordBook1.setB_Type(u_b_type);
            RecordBook1.setB_Price(u_b_price);
            RecordBook1.setB_p_id(u_b_pid);
            System.out.println("RecordBook1: B_Id:" + RecordBook1.getBook_id() + " B_Author:" + RecordBook1.getB_Author()
                                + " B_Title:" + RecordBook1.getB_Title() + " B_Type:" + RecordBook1.getB_Type()
                                + " B_Price(CAD$):" + RecordBook1.getB_Price() + " B_Price(Euro):" + RecordBook1.calculate_Price_Euro(u_b_price));
            
        
            u_b_id = inFile.nextInt();
            u_b_author = inFile.next();
            u_b_title = inFile.next();
            u_b_isbn = inFile.next();
            u_b_type = inFile.next();
            u_b_price = inFile.nextDouble();
            u_b_pid = inFile.nextInt();  
            
            RecordBook2.setBook_id(u_b_id);
            RecordBook2.setB_Author(u_b_author);
            RecordBook2.setB_Title(u_b_title);
            RecordBook2.setB_Isbn(u_b_isbn);
            RecordBook2.setB_Type(u_b_type);
            RecordBook2.setB_Price(u_b_price);
            RecordBook2.setB_p_id(u_b_pid);
            System.out.println("RecordBook2: B_Id:" + RecordBook2.getBook_id() + " B_Author:" + RecordBook2.getB_Author()
                                + " B_Title:" + RecordBook2.getB_Title() + " B_Type:" + RecordBook2.getB_Type()
                                + " B_Price(CAD$):" + RecordBook2.getB_Price() + " B_Price(Euro):" + RecordBook2.calculate_Price_Euro(u_b_price)); 
            
            
            u_b_id = inFile.nextInt();
            u_b_author = inFile.next();
            u_b_title = inFile.next();
            u_b_isbn = inFile.next();
            u_b_type = inFile.next();
            u_b_price = inFile.nextDouble();
            u_b_pid = inFile.nextInt();  
            
            RecordBook3.setBook_id(u_b_id);
            RecordBook3.setB_Author(u_b_author);
            RecordBook3.setB_Title(u_b_title);
            RecordBook3.setB_Isbn(u_b_isbn);
            RecordBook3.setB_Type(u_b_type);
            RecordBook3.setB_Price(u_b_price);
            RecordBook3.setB_p_id(u_b_pid);
            System.out.println("RecordBook3: B_Id:" + RecordBook3.getBook_id() + " B_Author:" + RecordBook3.getB_Author()
                                + " B_Title:" + RecordBook3.getB_Title() + " B_Type:" + RecordBook3.getB_Type()
                                + " B_Price(CAD$):" + RecordBook3.getB_Price() + " B_Price(Euro):" + RecordBook3.calculate_Price_Euro(u_b_price));         
            
            u_b_id = inFile.nextInt();
            u_b_author = inFile.next();
            u_b_title = inFile.next();
            u_b_isbn = inFile.next();
            u_b_type = inFile.next();
            u_b_price = inFile.nextDouble();
            u_b_pid = inFile.nextInt();  
            
            RecordBook4.setBook_id(u_b_id);
            RecordBook4.setB_Author(u_b_author);
            RecordBook4.setB_Title(u_b_title);
            RecordBook4.setB_Isbn(u_b_isbn);
            RecordBook4.setB_Type(u_b_type);
            RecordBook4.setB_Price(u_b_price);
            RecordBook4.setB_p_id(u_b_pid);
            System.out.println("RecordBook4: B_Id:" + RecordBook4.getBook_id() + " B_Author:" + RecordBook4.getB_Author()
                                + " B_Title:" + RecordBook4.getB_Title() + " B_Type:" + RecordBook4.getB_Type()
                                + " B_Price(CAD$):" + RecordBook4.getB_Price() + " B_Price(Euro):" + RecordBook4.calculate_Price_Euro(u_b_price));         
            
            u_b_id = inFile.nextInt();
            u_b_author = inFile.next();
            u_b_title = inFile.next();
            u_b_isbn = inFile.next();
            u_b_type = inFile.next();
            u_b_price = inFile.nextDouble();
            u_b_pid = inFile.nextInt();  
            
            RecordBook5.setBook_id(u_b_id);
            RecordBook5.setB_Author(u_b_author);
            RecordBook5.setB_Title(u_b_title);
            RecordBook5.setB_Isbn(u_b_isbn);
            RecordBook5.setB_Type(u_b_type);
            RecordBook5.setB_Price(u_b_price);
            RecordBook5.setB_p_id(u_b_pid);
            System.out.println("RecordBook5: B_Id:" + RecordBook5.getBook_id() + " B_Author:" + RecordBook5.getB_Author()
                                + " B_Title:" + RecordBook5.getB_Title() + " B_Type:" + RecordBook5.getB_Type()
                                + " B_Price(CAD$):" + RecordBook5.getB_Price() + " B_Price(Euro):" + RecordBook5.calculate_Price_Euro(u_b_price));   
            
            u_b_id = inFile.nextInt();
            u_b_author = inFile.next();
            u_b_title = inFile.next();
            u_b_isbn = inFile.next();
            u_b_type = inFile.next();
            u_b_price = inFile.nextDouble();
            u_b_pid = inFile.nextInt();  
            
            RecordBook6.setBook_id(u_b_id);
            RecordBook6.setB_Author(u_b_author);
            RecordBook6.setB_Title(u_b_title);
            RecordBook6.setB_Isbn(u_b_isbn);
            RecordBook6.setB_Type(u_b_type);
            RecordBook6.setB_Price(u_b_price);
            RecordBook6.setB_p_id(u_b_pid);
            System.out.println("RecordBook6: B_Id:" + RecordBook6.getBook_id() + " B_Author:" + RecordBook6.getB_Author()
                                + " B_Title:" + RecordBook6.getB_Title() + " B_Type:" + RecordBook6.getB_Type()
                                + " B_Price(CAD$):" + RecordBook6.getB_Price() + " B_Price(Euro):" + RecordBook6.calculate_Price_Euro(u_b_price));                   
    }
    
}
