package carproject;
 
public class Car {
 
    private int carNumber;
    private String carColor;
    private double carSpeed;
    private boolean carBreakBool;
    public static int carNumberSeats;
    public int numberWheels;
 
    public void setValue(int wcarNumber, String wcarColor, double wcarSpeed)
    {
        carNumber = wcarNumber;
        carColor = wcarColor;
        carSpeed = wcarSpeed;
    }
 
    public double IncreaseSpeed()
    {
        carSpeed = carSpeed * 2;
        System.out.println("\nThe Speed of the Car is doubled: " + carSpeed + "\n");
        return carSpeed;
    }
    
    public double DecreaseSpeed()
    {
        carSpeed = carSpeed - 20;
        System.out.println("\nThe Speed of the Car is decreased by 20km/h: " + carSpeed + "\n");
        return carSpeed;
    }    
    
    public boolean TrueBreak()
    {
        carBreakBool = true;
        return carBreakBool;
    }     
    
    public void printCarInfo()
    {
        System.out.println("The Car information is: " + carNumber + "//"
                + carColor + "//" + carSpeed + "km/h\n");
    }    
 
}