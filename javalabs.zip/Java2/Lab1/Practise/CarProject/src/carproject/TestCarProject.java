package carproject;

import java.util.Scanner;

public class TestCarProject {

    
    
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        int carNum;
        String carCol;
        double carSp;
        char ch;
                
        Car myGreenCar;
        myGreenCar = new Car();
          
        Car myRedCar;
        myRedCar = new Car();
                
        Car yourCar;
        yourCar = new Car();
              
        System.out.print("Line 2: After setting, myGreenCar\n");
                myGreenCar.setValue(1, "Green", 200.0);
        myGreenCar.printCarInfo();
        
        System.out.print("Line 5: After setting, myRedCar\n");
                myRedCar.setValue(2, "Red", 230.0);
        myRedCar.printCarInfo();        
        
        System.out.print("Line 8: After setting, yourCar\n");
                yourCar.setValue(3, "Black", 150.0);
        yourCar.printCarInfo();          

        System.out.print("New setting for the value object yourCar\n");
        System.out.print("Line 10: double the speed of yourCar object");
        yourCar.IncreaseSpeed();
        
        System.out.println("Line 11: After increasing the speed, new value of yourCar:");
        yourCar.printCarInfo();
        
        System.out.println("Now enter the values of object yourCar:");
        System.out.print("Car number: ");
        carNum = Integer.parseInt(console.nextLine());
        System.out.print("Car color: ");
        carCol = console.nextLine();        
        System.out.print("Car speed: ");
        carSp = console.nextDouble();          
        
        System.out.print("\nAfter setting, yourCar\n");
            yourCar.setValue(carNum, carCol, carSp);
        yourCar.printCarInfo();  
        
        System.out.print("Double the speed of yourCar object");
            yourCar.IncreaseSpeed();
        
        System.out.println("After increasing the speed, new value of yourCar:");
            yourCar.printCarInfo();
            
            myGreenCar.carNumberSeats = 2; 
 
            System.out.println("/n/n/n" +myRedCar.carNumberSeats);
            
            
            
    }
    
} 