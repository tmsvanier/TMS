package circleproject;

public class Circle
{
    private double radius;
    Point point;
    
    public Circle()
    {
        point = new Point();
        radius = 0.00;
    }
    public Circle(double redius)
    {
        point = new Point();
        this.radius =  redius;
    }

    public Circle(double redius, double x, double y)
    {
        point = new Point(x, y);
        this.radius =  redius;
        
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius =  radius;
    }
  
    public double CalculateArea()
    {
        return radius * radius * Math.PI;
    }

    public double CalculateCircumference()
    {
        return radius * 2 * Math.PI;
    }

    @Override
    public String toString()
    {
        return ",  radius = "  +  radius;
    }
    public void PrintPoint()
    {      
        System.out.printf("Radius:  %.2f \nArea: %.2f \nCircumference:  %.2f\n", radius, CalculateArea(), CalculateCircumference());
    }
    
}
