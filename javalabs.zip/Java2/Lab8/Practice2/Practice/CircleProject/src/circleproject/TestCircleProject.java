package circleproject;

public class TestCircleProject {


    public static void main(String[] args)
    {

      Circle Circle1=new Circle();
      Circle1.point.setX(10);
      Circle1.point.setY(20);
      Circle1.setRadius(5);
      
      System.out.println("Circle1:");
      Circle1.point.PrintPoint();
      Circle1.PrintPoint();

       Circle Circle2 = new Circle(50);        
       System.out.println("\n\nCircle2:");
       Circle2.point.PrintPoint();
       Circle2.PrintPoint();
       
        
    }
    
}
