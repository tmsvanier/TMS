
package bankaccountproject;

public class SavingAccount extends CheckingAccount implements BankingAccount
{
    private double interestRate;
    private double SavingAmount;

     
    public SavingAccount()
    {
       super();
       interestRate = 0;
       SavingAmount =0;
    }
    public SavingAccount(double interestRate, double SavingAmount)
    {
        super();
        this.interestRate = interestRate;
        this.SavingAmount = SavingAmount;
    }

    public SavingAccount( int clientID, String client_Name, double clientTotalAmount,double interestRate,double SavingAmount)
    {
        
        super(clientID, client_Name, clientTotalAmount);
        this.interestRate = interestRate;
        this.SavingAmount = SavingAmount;
    }
    
 

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public double getSavingAmount() {
        return SavingAmount;
    }

    public void setSavingAmount(double SavingAmount) {
        this.SavingAmount = SavingAmount;
    }
    
 

    @Override
    public String toString() {
        return super.toString() + " // " + interestRate + ",// " + SavingAmount+"\n";
    }
 

    @Override
    public void printInfo() 
    {
        super.printInfo();
        System.out.printf("\tSaving Amount = %.2f $%n\tInterest Rate: %.2f", SavingAmount,interestRate); 
    }

    @Override
    public double withdrawAmount(double Amount) 
    {
        return SavingAmount-=Amount;  
    }

    @Override
    public double AddAmount(double Amount)
    {
        return SavingAmount+=Amount;  
    }
    
    
    
}
