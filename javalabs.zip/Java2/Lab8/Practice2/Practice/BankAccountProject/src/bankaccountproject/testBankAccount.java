package bankaccountproject;

public class testBankAccount 
{


    public static void main(String[] args)
    {
       BankGInterface Bankingapplication = new BankGInterface();
    }
    
}
