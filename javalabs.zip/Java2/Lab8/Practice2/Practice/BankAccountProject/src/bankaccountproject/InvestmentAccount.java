package bankaccountproject;

public class InvestmentAccount extends CheckingAccount implements BankingAccount
{
    private double interestRate;
    private double investmentAmmount;


    public InvestmentAccount()
    {
        super();
        interestRate=0.00;
        investmentAmmount=0.00;
    }
    public InvestmentAccount(double interestRate, double investmentAmmount)
    {
        super();
        this.interestRate = interestRate;
        this.investmentAmmount = investmentAmmount;
    }

    public InvestmentAccount( int clientID, String clientName, double clientTotalAmount,double interestRate, double investmentAmmount) {
        super(clientID, clientName, clientTotalAmount);
        this.interestRate = interestRate;
        this.investmentAmmount = investmentAmmount;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public double getInvestmentAmmount() {
        return investmentAmmount;
    }

    public void setInvestmentAmmount(double investmentAmmount) {
        this.investmentAmmount = investmentAmmount;
    }

    
    @Override
    public double withdrawAmount(double Amount) {
        return investmentAmmount-=Amount; 
    }

    @Override
    public double AddAmount(double Amount) {
        return investmentAmmount+=Amount; 
    }
    
    @Override
    public void printInfo() {
        super.printInfo();
        System.out.printf("\t investmentAmmount= %.2f $%n\tInterest Rate: %.2f", investmentAmmount,interestRate);
    }


    @Override
    public String toString() {
        return super.toString()+" // " + interestRate + ",// " + investmentAmmount+"\n";
    }
    
    
}
