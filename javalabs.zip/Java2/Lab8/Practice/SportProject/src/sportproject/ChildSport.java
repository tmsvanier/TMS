package sportproject;

public class ChildSport extends Sport  {
    
    
    private double cost_pro;
    
    public ChildSport(String namet, double number_hourt, double number_weekt, double cost_prot) {
        super(namet, number_hourt, number_weekt);
        cost_pro=cost_prot;
    }    
    

    public double CalculateCostTraining()
    {
        return super.CalculateCostTraining()+ cost_pro;
    }
    
    @Override
    public String toString()
    {
         return super.toString() + "//" + cost_pro;
    }    
}
