 
package payrollproject;

 
public class TestPayRoll {

 
    public static void main(String[] args) {

    
    GUIPayRoll TestPayRoll = new GUIPayRoll();

        
    
    }
    
}
