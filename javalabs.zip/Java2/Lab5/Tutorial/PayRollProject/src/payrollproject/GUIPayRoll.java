 
package payrollproject;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
 
public class GUIPayRoll implements ActionListener{
        JTextField employeeName, SSN, number_whr, h_rate, Total_Income, Net_Amount;
        

   
        
 public  GUIPayRoll() {
        

        JFrame wframe = new JFrame();
        JLabel employeeNameL = new JLabel("Enter Employee's name: ", SwingConstants.RIGHT);
        JLabel SSNL = new JLabel("Enter Employee's SSN: ", SwingConstants.RIGHT);
        JLabel number_whrL = new JLabel("Enter the number of Worked Hour: ", SwingConstants.RIGHT);
        JLabel h_rateL = new JLabel("Enter the rate hour: ", SwingConstants.RIGHT);
        JLabel Total_IncomeL = new JLabel("Total Income: ", SwingConstants.RIGHT);
        JLabel Net_AmountL = new JLabel("Net Amount: ", SwingConstants.RIGHT);
        
        employeeName = new JTextField(10);
        SSN = new JTextField(10);
        number_whr = new JTextField(10);
        h_rate = new JTextField(10);
        Total_Income = new JTextField(10);
        Net_Amount = new JTextField(10);
        
        JButton calculateB = new JButton("Calculate");
        calculateB.addActionListener(this);
        JButton exitB = new JButton("Exit");
        exitB.addActionListener(this);
        JButton printPayStub = new JButton("Print Pay Stub");
        printPayStub.addActionListener(this);

        wframe.setTitle("Pay Roll Application");
        
        wframe.setSize(450, 250);
        wframe.setVisible(true);
        
        Container pane = wframe.getContentPane();
        pane.setLayout(new GridLayout(8, 2));
        pane.add(employeeNameL);
        pane.add(employeeName);
        pane.add(SSNL);
        pane.add(SSN);
        pane.add(number_whrL);
        pane.add(number_whr);
        pane.add(h_rateL);
        pane.add(h_rate);
        pane.add(Total_IncomeL);
        pane.add(Total_Income);
        pane.add(Net_AmountL);
        pane.add(Net_Amount);   
        pane.add(calculateB);
        pane.add(exitB); 
        pane.add(printPayStub);
        
    }
 
 
            double number_whr2, h_rate2, Total_Income2, Net_Amount2;
            String employeeName2, SSN2;

            double Prv_Tax = 0.09;
            double Fed_Tax = 0.07;
            double QP_Ins = 0.0055;
            double E_ins = 0.014;
            double Qpp = 0.045;
            double Union_d = 0.0165;
            double ded_Prv_Tax, deductions, ded_Fed_Tax, ded_QP_Ins, ded_E_ins, ded_Qpp, ded_Union_d;

    public void actionPerformed(ActionEvent e) {

           
               if(e.getActionCommand().equals("Calculate"))
                        {
                          employeeName2 = employeeName.getText();
                          SSN2 = SSN.getText();
                          number_whr2 = Double.parseDouble(number_whr.getText());
                          h_rate2 = Double.parseDouble(h_rate.getText());
 
                          
                            Total_Income2 = number_whr2 * h_rate2;

                            ded_Prv_Tax = Prv_Tax * Total_Income2;
                            ded_Fed_Tax = Fed_Tax * Total_Income2;
                            ded_QP_Ins = QP_Ins * Total_Income2;
                            ded_E_ins = E_ins * Total_Income2;
                            ded_Qpp = Qpp * Total_Income2;
                            ded_Union_d = Union_d * Total_Income2;

                            deductions = ded_Prv_Tax + ded_Fed_Tax + ded_QP_Ins + ded_E_ins + ded_Qpp + ded_Union_d;
                            Net_Amount2 = Total_Income2 - deductions;


                          
                          
                          Total_Income.setText("" + Total_Income2);
                          Net_Amount.setText("" + Net_Amount2);
                          

                }
               
                 else if(e.getActionCommand().equals("Print Pay Stub"))
                            { 

                             String output = String.format("\nThe Total Earning is: %.2f $\n"
                                    + "     The Fed_Tax Deduction is:  %.2f $\n"
                                    + "     The Prv_Tax Deduction is:  %.2f $\n"
                                    + "     The QP_Ins Deduction is: %.2f $\n"
                                    + "     The E_ins Deduction is: %.2f $\n"
                                    + "     The Qpp Deduction is: %.2f $\n"
                                    + "     The Union_d Deduction is: %.2f $\n"
                                    + "     The Total Deduction is: %.2f $\n\n"
                                    + "The Total Net Amount is: %.2f $\n", Total_Income2, ded_Fed_Tax, ded_Prv_Tax, ded_QP_Ins, ded_E_ins, ded_Qpp, ded_Union_d, deductions, Net_Amount2);

                                 JOptionPane.showMessageDialog(null, output, "Pay Stub", JOptionPane.PLAIN_MESSAGE); 
                            }
                          

                  else if(e.getActionCommand().equals("Exit"))
                  {
                      System.exit(0);
                  }

              
              
              
              

                     
     
     }
    
}