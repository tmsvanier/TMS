 
package rectangleproject;
 
import javax.swing.*;
 
public class TestRectangleJFrame1 {

 

    public static void main(String[] args) {

//        double lengthTF, widthTF, areaTF, perimeterTF;
//        
//        System.out.println("The Area and Perimeter of Rectangle");
//        System.out.print("\n Enter Length of rectangle: ");
//            lengthTF = console.nextDouble();
//        System.out.print(" Enter the Width of rectangle: ");
//            widthTF = console.nextDouble();              
//        System.out.println("\nThe area of rectangle is: " + lengthTF*widthTF);
//        System.out.println("The perimeter of rectangle is: " + (lengthTF+widthTF)*2);
        JFrame wframe = new JFrame();
        
        wframe.setTitle("Area and Perimeter of a Rectangle");
        
        wframe.setSize(400, 300);
        wframe.setVisible(true);
        
 
        
    }
    
    
}
