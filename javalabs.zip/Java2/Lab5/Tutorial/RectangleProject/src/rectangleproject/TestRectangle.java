 
package rectangleproject;

import java.util.*;
import java.io.*;

public class TestRectangle {

static Scanner console = new Scanner(System.in);

    public static void main(String[] args) {

        double lengthTF, widthTF, areaTF, perimeterTF;
        
        System.out.println("The Area and Perimeter of Rectangle");
        System.out.print("\n Enter Length of rectangle: ");
            lengthTF = console.nextDouble();
        System.out.print(" Enter the Width of rectangle: ");
            widthTF = console.nextDouble();              
        System.out.println("\nThe area of rectangle is: " + lengthTF*widthTF);
        System.out.println("The perimeter of rectangle is: " + (lengthTF+widthTF)*2);
        
        
    }
    
}
