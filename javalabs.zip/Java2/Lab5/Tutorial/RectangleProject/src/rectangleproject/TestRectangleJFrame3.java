 
package rectangleproject;
 
import javax.swing.*;
import java.awt.*;
public class TestRectangleJFrame3 {

 

    public static void main(String[] args) {

//        double lengthTF, widthTF, areaTF, perimeterTF;
//        
//        System.out.println("The Area and Perimeter of Rectangle");
//        System.out.print("\n Enter Length of rectangle: ");
//            lengthTF = console.nextDouble();
//        System.out.print(" Enter the Width of rectangle: ");
//            widthTF = console.nextDouble();              
//        System.out.println("\nThe area of rectangle is: " + lengthTF*widthTF);
//        System.out.println("The perimeter of rectangle is: " + (lengthTF+widthTF)*2);
        JFrame wframe = new JFrame();
        JLabel lengthL = new JLabel("Enter the Length: ", SwingConstants.RIGHT);
        JLabel widthL = new JLabel("Enter the width: ", SwingConstants.RIGHT);
        JLabel areaL = new JLabel("Area: ", SwingConstants.RIGHT);
        JLabel perimeterL = new JLabel("Perimeter: ", SwingConstants.RIGHT);
        
        wframe.setTitle("Area and Perimeter of a Rectangle");
        
        wframe.setSize(400, 300);
        wframe.setVisible(true);
        
        Container pane =  wframe.getContentPane();
        pane.setLayout(new GridLayout(5, 2));
        pane.add(lengthL);
        pane.add(widthL);
        pane.add(areaL);
        pane.add(perimeterL);
    }
    
    
}
