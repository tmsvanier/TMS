 
package rectangleproject;
 

public class TestRectangleJFrame8 {


     public static void main(String[] args) {
         
         GUIRectangleJFrame8 TestRectangleProgram = new GUIRectangleJFrame8();
         
     }
     

    
}