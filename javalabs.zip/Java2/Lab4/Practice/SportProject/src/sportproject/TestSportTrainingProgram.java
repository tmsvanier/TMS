 
package sportproject;
import java.io.*;
import java.util.Scanner;
 
public class TestSportTrainingProgram {


    public static void main(String[] args) throws FileNotFoundException
    {
            PrintWriter outFile = new PrintWriter("Sport.out");

    Scanner  console = new Scanner(System.in);
    String u_Name;
    double u_Number_hour, u_Number_week, u_CostHour;
    
    System.out.println("The sport Training application built with Object Oriented Programming (OOP");
    System.out.print("Enter name: ");
    u_Name = console.next();
    System.out.print("Enter number of Sport Training HOurs per Week: ");
    u_Number_hour = console.nextDouble();
    System.out.print("Enter number of Weeks Sport Training: ");
    u_Number_week = console.nextDouble();
    System.out.print("Enter the cost of Sport Training per hour: ");
    u_CostHour = console.nextDouble();    

    
    Sport yourSport = new Sport();
    yourSport.setName(u_Name);
    yourSport.setNumber_hour(u_Number_hour);
    yourSport.setNumber_week(u_Number_week);
    Sport.cost_hour = u_CostHour;
    
    System.out.println("After setting, yourSport object, ");  
    System.out.print("The sport Training information is: ");      
    System.out.println(yourSport);
    
    System.out.println("\n\t The cost of Sport Training of yourSport object is " + yourSport.CalculateCostTraining() + "$");
    outFile.println("yourSport " + yourSport.getName() + "  " + yourSport.getNumber_hour() + "  " + yourSport.getNumber_week() + "  " + yourSport.cost_hour + " " + yourSport.CalculateCostTraining() + "$");
        
    Sport mySport1 = new Sport();
    mySport1.setName("Bob");
    mySport1.setNumber_hour(3);
    mySport1.setNumber_week(12);
    Sport.cost_hour = u_CostHour;
    
    System.out.println("\nAfter setting, mySport1 object, ");  
    System.out.print("The sport Training information is: ");      
    System.out.println(mySport1);
    
    System.out.println("\n\t The cost of Sport Training of mySport1 object is " + mySport1.CalculateCostTraining() + "$");
        outFile.println("mySport1 " + mySport1.getName() + "  " + mySport1.getNumber_hour() + "  " + mySport1.getNumber_week() + "  " + mySport1.cost_hour + " " + mySport1.CalculateCostTraining() + "$");

       
    Sport mySport2 = new Sport("Irena", 17, 52);
    Sport.cost_hour = u_CostHour;
    
    System.out.println("\nAfter setting, mySport2 object, ");  
    System.out.print("The sport Training information is: ");      
    System.out.println(mySport2);
    
    System.out.println("\n\t The cost of Sport Training of mySport1 object is " + mySport2.CalculateCostTraining() + "$");
    outFile.println("mySport2 " + mySport2.getName() + "  " + mySport2.getNumber_hour() + "  " + mySport2.getNumber_week() + "  " + mySport2.cost_hour + " " + mySport2.CalculateCostTraining() + "$");
        
    mySport2.setName("Samantha");
    mySport2.setNumber_hour(10);
    mySport2.setNumber_week(48);
    
    System.out.println("\nAfter setting, mySport2 object, ");  
    System.out.print("The sport Training information is: ");      
    System.out.println(mySport2);
    
    System.out.println("\n\t The cost of Sport Training of mySport1 object is " + mySport2.CalculateCostTraining() + "$");
    outFile.println("mySport2 " + mySport2.getName() + "  " + mySport2.getNumber_hour() + "  " + mySport2.getNumber_week() + "  " + mySport2.cost_hour + " " + mySport2.CalculateCostTraining() + "$");
            
    System.out.println("\nTo Access the data members of mySport2 Object, ");
    System.out.println("Name: " + mySport2.getName());        
    System.out.println("Number of Hours: " + mySport2.getNumber_hour());  
    System.out.println("Number of weeks: " + mySport2.getNumber_week());  
    System.out.println("Cost per hour: " + Sport.cost_hour +"$");        
        
    
    System.out.println("\nThe total of Sport Training of yourSport, mySport1, mySport2 objects is " + (yourSport.CalculateCostTraining() + mySport1.CalculateCostTraining() + mySport2.CalculateCostTraining()));   
    Sport mySport3= new Sport(yourSport);
    
    System.out.println("\nAfter setting, mySport3 object, ");  
    System.out.print("The sport Training information is: ");      
    System.out.println(mySport3);
        System.out.println("\t The cost of Sport Training of mySport3 object is " + mySport3.CalculateCostTraining() + "$");

    outFile.println("mySport3 " + mySport3.getName() + "  " + mySport3.getNumber_hour() + "  " + mySport3.getNumber_week() + "  " + mySport3.cost_hour + " " + mySport3.CalculateCostTraining() + "$");
    System.out.println("\nRemember, yourSport object, ");  
    System.out.print("The sport Training information is: ");      
    System.out.println(yourSport);
        System.out.println("\t The cost of Sport Training of mySport1 object is " + yourSport.CalculateCostTraining() + "$");

    Scanner inFile = new Scanner(new FileReader("Sport.in"));
    Sport RecordSport1 = new Sport();
    Sport RecordSport2 = new Sport();   
    Sport RecordSport3 = new Sport();    
    Sport RecordSport4 = new Sport();    
    Sport RecordSport5 = new Sport();    
    
    String n1, n2;
    
    System.out.println("\nReading Sport.in records from an input file (Simulate Oracle Table Reading");

    
    n1 = inFile.next();
    n2 = inFile.next();
    u_Name = n1 + " " + n2;
    
    u_Number_hour = inFile.nextDouble();
    u_Number_week = inFile.nextDouble();
    u_CostHour = inFile.nextDouble();       

    RecordSport1.setName(u_Name);
    RecordSport1.setNumber_hour(u_Number_hour);
    RecordSport1.setNumber_week(u_Number_week);
    u_CostHour = RecordSport1.cost_hour;
    
    System.out.println("\nAfter setting, RecordSport1 object, ");  
    System.out.print("The sport Training information is: ");      
    System.out.println(RecordSport1);
    
    System.out.println("\n\t The cost of Sport Training of RecordSport1 object is " + RecordSport1.CalculateCostTraining() + "$");
    outFile.println("RecordSport1 " + RecordSport1.getName() + "  " + RecordSport1.getNumber_hour() + "  " + RecordSport1.getNumber_week() + "  " + RecordSport1.cost_hour + " " + RecordSport1.CalculateCostTraining() + "$");
      
    
    n1 = inFile.next();
    n2 = inFile.next();
    u_Name = n1 + " " + n2;
    
    u_Number_hour = inFile.nextDouble();
    u_Number_week = inFile.nextDouble();
    u_CostHour = inFile.nextDouble();       

    RecordSport2.setName(u_Name);
    RecordSport2.setNumber_hour(u_Number_hour);
    RecordSport2.setNumber_week(u_Number_week);
    u_CostHour = RecordSport2.cost_hour;
    
    System.out.println("\nAfter setting, RecordSport2 object, ");  
    System.out.print("The sport Training information is: ");      
    System.out.println(RecordSport2);
    
    System.out.println("\n\t The cost of Sport Training of RecordSport2 object is " + RecordSport2.CalculateCostTraining() + "$");
    outFile.println("RecordSport2 " + RecordSport2.getName() + "  " + RecordSport2.getNumber_hour() + "  " + RecordSport2.getNumber_week() + "  " + RecordSport2.cost_hour + " " + RecordSport2.CalculateCostTraining() + "$");
      
        
        
    n1 = inFile.next();
    n2 = inFile.next();
    u_Name = n1 + " " + n2;
    
    u_Number_hour = inFile.nextDouble();
    u_Number_week = inFile.nextDouble();
    u_CostHour = inFile.nextDouble();       

    RecordSport3.setName(u_Name);
    RecordSport3.setNumber_hour(u_Number_hour);
    RecordSport3.setNumber_week(u_Number_week);
    u_CostHour = RecordSport3.cost_hour;
    
    System.out.println("\nAfter setting, RecordSport3 object, ");  
    System.out.print("The sport Training information is: ");      
    System.out.println(RecordSport3);
    
    System.out.println("\n\t The cost of Sport Training of RecordSport3 object is " + RecordSport3.CalculateCostTraining() + "$");
    outFile.println("RecordSport3 " + RecordSport3.getName() + "  " + RecordSport3.getNumber_hour() + "  " + RecordSport3.getNumber_week() + "  " + RecordSport3.cost_hour + " " + RecordSport3.CalculateCostTraining() + "$");
      
        
    n1 = inFile.next();
    n2 = inFile.next();
    u_Name = n1 + " " + n2;
    
    u_Number_hour = inFile.nextDouble();
    u_Number_week = inFile.nextDouble();
    u_CostHour = inFile.nextDouble();       

    RecordSport4.setName(u_Name);
    RecordSport4.setNumber_hour(u_Number_hour);
    RecordSport4.setNumber_week(u_Number_week);
    u_CostHour = RecordSport4.cost_hour;
    
    System.out.println("\nAfter setting, RecordSport4 object, ");  
    System.out.print("The sport Training information is: ");      
    System.out.println(RecordSport4);
    
    System.out.println("\n\t The cost of Sport Training of RecordSport4 object is " + RecordSport4.CalculateCostTraining() + "$");
    outFile.println("RecordSport4 " + RecordSport4.getName() + "  " + RecordSport4.getNumber_hour() + "  " + RecordSport4.getNumber_week() + "  " + RecordSport4.cost_hour + " " + RecordSport4.CalculateCostTraining() + "$");
      
            
    n1 = inFile.next();
    n2 = inFile.next();
    u_Name = n1 + " " + n2;
    
    u_Number_hour = inFile.nextDouble();
    u_Number_week = inFile.nextDouble();
    u_CostHour = inFile.nextDouble();       

    RecordSport5.setName(u_Name);
    RecordSport5.setNumber_hour(u_Number_hour);
    RecordSport5.setNumber_week(u_Number_week);
    u_CostHour = RecordSport5.cost_hour;
    
    System.out.println("\nAfter setting, RecordSport5 object, ");  
    System.out.print("The sport Training information is: ");      
    System.out.println(RecordSport5);
    
    System.out.println("\n\t The cost of Sport Training of RecordSport5 object is " + RecordSport5.CalculateCostTraining() + "$");
    outFile.println("RecordSport5 " + RecordSport5.getName() + "  " + RecordSport5.getNumber_hour() + "  " + RecordSport5.getNumber_week() + "  " + RecordSport5.cost_hour + " " + RecordSport5.CalculateCostTraining() + "$");
      
            
    System.out.println("\n The Total cost of Sport Training of RecordSport1,2,3,4,5 objects is " + (RecordSport1.CalculateCostTraining() + RecordSport2.CalculateCostTraining() + RecordSport3.CalculateCostTraining()+RecordSport4.CalculateCostTraining()+RecordSport5.CalculateCostTraining())+"$");
        
    
    
    Sport mySport4= new Sport(RecordSport4);
    
    System.out.println("\nAfter setting, mySport4 object, ");  
    System.out.print("The sport Training information is: ");      
    System.out.println(mySport4);
        System.out.println("\t The cost of Sport Training of mySport4 object is " + mySport4.CalculateCostTraining() + "$");


    inFile.close();
    outFile.close();
    
    char ch;
    do
       {
        System.out.print("\n\n\nSearching for a given Athlete using the method doSearch(...), SportFound object,\n"
                + "Enter Name you would like to Search: ");
           
        inFile = new Scanner(new FileReader("Sport.in")); 
        Sport Found = new Sport();
        String searchName=console.next() + " " + console.next();
        Found.setName(searchName);
        Found=Sport.doSearch(inFile, searchName);
      
        
        if (Found.getName().equals(searchName))
        {
            System.out.println(Found.getName()+" Athleth is found, and its data,");
            System.out.println("Name: "+Found.getName());
            System.out.println("Number of Hours: "+Found.getNumber_hour());
            System.out.println("Number of Weeks: "+Found.getNumber_week());
            System.out.println("Cost per Hour: "+Sport.cost_hour);
            System.out.println("Cost of Training: "+Found.CalculateCostTraining());            
            
        }
        else
        {
            System.out.println("Athlete not found");
        }

        
        
        System.out.print("Do you want to enter new search y/n?: ");
 
        ch = console.next().charAt(0);
 
        inFile.close();
      }
    while (ch == 'y' || ch == 'Y');   

    
    }
    
}
