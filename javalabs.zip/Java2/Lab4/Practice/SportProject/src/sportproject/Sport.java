 
package sportproject;
 
import java.util.Scanner;

 
public class Sport {
    private String name;
    private double number_hour, number_week;
    public static double cost_hour;
    
    public Sport() {
        name= "";
        number_hour=0.00;
        number_week=0.00; 
    }
    
    public Sport(String namet, double number_hourt, double number_weekt) {
        name=namet;
        number_hour=number_hourt;
        number_week=number_weekt; 
    }    
    
    public void setName(String namet2)
    {
        name=namet2;
    }    
    
    public void setNumber_hour(double number_hourt2)
    {
        if (number_hourt2 < 0)
            System.out.println("Error. Please enter a positive value.");
        else
            number_hour=number_hourt2;
    }     
    
    public void setNumber_week(double number_weekt2)
    {
        if (number_weekt2 < 0)
            System.out.println("Error. Please enter a positive value.");
        else 
            number_week=number_weekt2;
    }        
    public double CalculateCostTraining()
    {
        double cost_training;
        cost_training = cost_hour * number_hour * number_week;
        return cost_training;
    }
    
    public String toString()
     {
         return("//" + name + "//" + number_hour + "//" + number_week + "//" + cost_hour +"$");
     }
    
    public String getName()
    {
        return name;
    }
    
    public double getNumber_hour()
    {
        return number_hour;
    }    
    
    public double getNumber_week()
    {
        return number_week;
    }     
    
    
    public Sport(Sport vSport)
    {
        name = vSport.name;
        number_hour = vSport.number_hour;
        number_week = vSport.number_week;
    }  
     
    

public static Sport doSearch(Scanner inFile, String byName)
    {
        Sport sportFound=new Sport();
        String name;
        double hour;
        double price;
        int week;
       
        while (inFile.hasNextLine())
         {
             name=inFile.next() + " " + inFile.next();
             hour=inFile.nextDouble();
             week=inFile.nextInt();
             price=inFile.nextDouble();
             
            
             if(name.equals(byName))  
             {
                  
                 sportFound.name=name;  
                 sportFound.number_hour=hour;
                 sportFound.number_week=week;
                 Sport.cost_hour=price;
                                 
                 break;
             } 

         }
       
        return sportFound; 
        
    }
      
}
