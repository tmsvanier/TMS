/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package generaltripproject;

/**
 *
 * @author cstuser
 */
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;
public class TripGuInterface extends JFrame implements ActionListener,ItemListener,ListSelectionListener
{
    
    private  int width=900;
    private  int height=900;
    //create 2 reference object of Trip class
    Trip myTrip,yourTrip,inputtrip;
    //create a reference object of JTextArea class
    JTextArea showoutputTA;
    //create a reference object of the class of JList 
    JList tripMemberJL;
    //create an array of stirng type to linked in to JList object
    String[] TripMembrer_Str={"gas_Price","Distance","Hotel_cost","Food_cost"};
    
    //menu Item
    JMenuItem inputJMI,myTripJMI,yourTripJMI,polymorphismJMI,exitJMI;
    
    
    public TripGuInterface()
    {
        
        /* not use when your extends from JFrame
        //JFrame tripFrame;
        //instantiate tripFrame object and instanciate pane object from Container class then 
        //tripFrame=new JFrame();
        */
        setTitle("General Trip Menu");
        Container pane=getContentPane();
       // tripFrame.getContentPane(); !!!!!!!!!!!!!!! do not use 
        pane.setLayout(null);
        
        
        //create a JMBar Object
        JMenuBar TripmenuBarJMB;
        TripmenuBarJMB=new JMenuBar();
        setJMenuBar(TripmenuBarJMB);
        
        
       //Create 3 menu and then add MenuItem to the very 3 menu
        
        //1st menu
        JMenu inputM=new JMenu("Input Trip Data");
        //1st menuItem
        inputJMI=new JMenuItem("input from JList");//instanciate menuItem from Input and then add it to 1st menu
        inputM.add(inputJMI); //add to 1st menu
        inputJMI.addItemListener(this);//register this menuItem
        //2nd menuItem
        exitJMI=new JMenuItem("Exit");
        inputM.add(exitJMI); //add to 2st menuItem to input
        
        //2nd Menu
        JMenu outputM=new JMenu("OutputTripData");
        myTripJMI=new JMenuItem("my Trip");//add 1st item to list
        outputM.add(myTripJMI);
        myTripJMI.addActionListener(this);
       //2nd item        
        yourTripJMI=new JMenuItem("yoru Trip");//create 2nd item to the output Menu
        outputM.add(yourTripJMI);
        yourTripJMI.addActionListener(this);
        
        //3rd menu
        
        JMenu polyJM=new JMenu("PolyMorphism");
        //create 1st Item
        polymorphismJMI=new JMenuItem("Test poly");
        polymorphismJMI.addActionListener(this);
        //add to 3rd menu
        polyJM.add(polymorphismJMI);
        
        
        //instantiate tripMemberJL JList
        tripMemberJL=new JList(TripMembrer_Str);
        tripMemberJL.setVisibleRowCount(4);
        tripMemberJL.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tripMemberJL.addListSelectionListener(this);
        
        //instanciate text area
        showoutputTA=new JTextArea();
        
        
        //add menu have been created before to the MenuBar
        TripmenuBarJMB.add(inputM);
        TripmenuBarJMB.add(outputM);
        TripmenuBarJMB.add(polyJM);
        
        
        //set and location  in the layout
        tripMemberJL.setLocation(50,50);
        showoutputTA.setLocation(50,185);
        //set size
        tripMemberJL.setSize(400,100);
        showoutputTA.setSize(600,400);
                
                
                
        //add component to the pane
       
        pane.add(tripMemberJL);
        pane.add(showoutputTA);
        
        //visibility
        setSize(width, height);
        setVisible(true);
       setDefaultCloseOperation(EXIT_ON_CLOSE);
       
        
      
       inputtrip=new Trip();
    }
    @Override
    public void valueChanged(ListSelectionEvent e)
    {
        String astr="";
        double temp;int distance;
        if (!e.getValueIsAdjusting())
        {
            //select 1st index of list
             if(tripMemberJL.getSelectedIndex()==0)
             {
                 
                 astr=JOptionPane.showInputDialog(null,"Enter gas price ",
                         " Input", JOptionPane.INFORMATION_MESSAGE);
                temp= Double.parseDouble(astr);
                inputtrip.setGas_price(temp);
               
                 }
             if(tripMemberJL.getSelectedIndex()==1)
             {
                 
                 astr=JOptionPane.showInputDialog(null,"Enter Trip Distance ",
                         " Input", JOptionPane.INFORMATION_MESSAGE);
                 distance=Integer.parseInt(astr);
                 inputtrip.setDistance(distance);
                 }
              if(tripMemberJL.getSelectedIndex()==2)
             {
                 
                 astr=JOptionPane.showInputDialog(null,"Enter The cosst of Hotel ",
                         " Input", JOptionPane.INFORMATION_MESSAGE);
                temp= Double.parseDouble(astr);
                Trip.Hotel_cost=temp;
                 }
               if(tripMemberJL.getSelectedIndex()==3)
                 {
                 
                 astr=JOptionPane.showInputDialog(null,"Enter The cosst Food ",
                         " Input", JOptionPane.INFORMATION_MESSAGE);
                temp= Double.parseDouble(astr);
                
               inputtrip.Food_cost=temp;
                showInfo(inputtrip,"myTripObject"," ");
                 }
                
        }
    }

    @Override
    public void itemStateChanged(ItemEvent e) 
    {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        myTrip=new Trip(15,3,15);
        yourTrip=new Trip(25,5,60);
        
         if( e.getSource()==myTripJMI)
         {
             Trip.Hotel_cost=10;
            showInfo(myTrip,"myTripObject"," ");
         }
         if( e.getSource()==yourTripJMI)
         {
             Trip.Hotel_cost=10;
            showInfo(yourTrip,"yourTripObject"," ");
         }
         if( e.getSource()==exitJMI)
         {
             System.exit(0);
         
         }
    }
    public void showInfo(Trip tobject, String title,String tripobject)
    {
        
        String str="\n";
        str+="this is the infomation of "+title+"\n";
        str+=tripobject+" Gas price="+tobject.getGas_price()+" $,Distance= "+tobject.getDistance()+
                " ,Hotel Cost= "+Trip.Hotel_cost+" $ ,Food Cost= "+tobject.Food_cost+" $, The total cost is :"+
                        String.format("%.2f $",tobject.TripCost())+"\n";        
        showoutputTA.append(""+str);
    }

    
}
