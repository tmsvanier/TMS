/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package generaltripproject;

/**
 *
 * @author cstuser
 */
public class Trip 
{
    private double gas_price;
    private  int distance;
    public static double Hotel_cost;
    public double Food_cost;
   

     public Trip() {
        gas_price = 0;
        Hotel_cost = 0;
        Food_cost = 0;
        distance = 0;
    }
    public Trip(double gprice, int d, double fc )
    {
        gas_price = gprice;
//        Hotel_cost = hc;
        Food_cost = fc;
        distance = d;
    }

    public  double getGas_price()
    {
        return gas_price;
    }

    public  void setGas_price(double gprice)
    {
        gas_price = gprice;
    }

    public  int getDistance()
    {
        return distance;
    }

    public  void setDistance(int d) {
        distance = d;
    }

   
    

    public double getFood_cost() {
        return Food_cost;
    }

    public void setFood_cost(double Food_cost) {
        this.Food_cost = Food_cost;
    }

   
    @Override
    public String toString() {
        return "Trip{" + "gas_price=" + gas_price + ", Hotel_cost=" + Hotel_cost + ", Food_cost=" + Food_cost + ", distance=" + distance + '}';
    }
    public   double TripCost()
    {
        return (gas_price*distance)+Hotel_cost+Food_cost ;
    }
    
}
