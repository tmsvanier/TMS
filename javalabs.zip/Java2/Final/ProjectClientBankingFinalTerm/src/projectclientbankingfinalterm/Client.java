package projectclientbankingfinalterm;



public class Client {
    
    
    private int client_id;
    private String client_name;
    private double client_StUnit, client_StPrice;
    
    public Client()
    {
        client_id=0;
        client_name="";
        client_StUnit=0;
        client_StPrice=0;
    }
    
    public Client(int client_idT, String client_nameT, double client_StUnitT, double client_StPriceT)
    {
        client_id=client_idT;
        client_name=client_nameT;
        client_StUnit=client_StUnitT;
        client_StPrice=client_StPriceT;
    }    
    
    public void setclient_id(int client_idT)
    {
        client_id=client_idT;
    }    
    
    public void setclient_name(String client_nameT)
    {
        client_name=client_nameT;
    }        
    
    public void setclient_StUnit(double client_StUnitT)
    {
        client_StUnit=client_StUnitT;
    }       
    
    public void setclient_StPrice(double client_StPriceT)
    {
        client_StPrice=client_StPriceT;
    }        

    public int getClient_id() {
        return client_id;
    }

    public String getClient_name() {
        return client_name;
    }

    public double getClient_StUnit() {
        return client_StUnit;
    }

    public double getClient_StPrice() {
        return client_StPrice;
    }
    
    
    
    public double CalculateClientInvestment()
    {
        double Tot_Investment = client_StUnit * client_StPrice;
        return Tot_Investment;
        
    }    
}
