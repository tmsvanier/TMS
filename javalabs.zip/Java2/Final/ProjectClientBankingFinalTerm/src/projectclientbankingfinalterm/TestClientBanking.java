
package projectclientbankingfinalterm;

import java.awt.*;
import java.awt.event.*; 
import javax.swing.*;
public class TestClientBanking extends JFrame implements ActionListener, ItemListener{

    JLabel clientID, clientName, clientStock, clientPrice, totalInvestment;
    JTextField clientIDTF, clientNameTF;
    JRadioButton stock100, stock200, stock300;
    JTextArea resultTA;    
    ButtonGroup stockGroup ;
    JButton resultButton;
    JComboBox priceUnit;
    
    static int clientIDI;
    static String clientNameI;
    static double clientStUnitI, clientStPriceI;
    String[] prices = {"49.99","79.99","119.99","149.99"};
    
    public TestClientBanking() {
        

       stock100 = new JRadioButton("100 Stock Unit");
       stock200 = new JRadioButton("200 Stock Unit");
       stock300 = new JRadioButton("300 Stock Unit");
       
       clientIDTF = new JTextField(10);
       clientNameTF = new JTextField(10);
       
       stockGroup = new ButtonGroup();       
       stockGroup.add(stock100);
       stockGroup.add(stock200);
       stockGroup.add(stock300);    
       
       stock100.addItemListener(this);
       stock200.addItemListener(this);
       stock300.addItemListener(this); 
       
       resultButton = new JButton("Calculate");
       resultButton.addActionListener(this);       

        
            priceUnit = new JComboBox(prices);
            priceUnit.addItemListener(this);    

       clientID = new JLabel("Enter client ID:");
       clientName = new JLabel("Enter client Name:");
       clientStock = new JLabel("Choose client stock unit:");
       clientPrice = new JLabel("Choose client price unit:");
       totalInvestment = new JLabel("Total investment:");

       resultTA = new JTextArea(500,150);
       
       resultTA.setLocation(50,350);
       totalInvestment.setLocation(50,310);
       resultButton.setLocation(150, 310);
       clientStock.setLocation(50, 110);
       clientPrice.setLocation(350, 110);
       clientID.setLocation(80,20);
       clientName.setLocation(80,60);
       stock100.setLocation(85,130);
       stock200.setLocation(85,150);
       stock300.setLocation(85,170);
       priceUnit.setLocation(350, 130);
       clientIDTF.setLocation(200, 20);
       clientNameTF.setLocation(200, 60);       
 
 
       resultTA.setSize(490, 152);
       clientID.setSize(160, 35);
       clientName.setSize(120,35);
       clientStock.setSize(150, 25);
       clientPrice.setSize(150, 25);
       totalInvestment.setSize(120, 25);
       stock100.setSize(120, 25);
       stock200.setSize(120, 25);
       stock300.setSize(120, 25);
       resultButton.setSize(120, 25);
       priceUnit.setSize(100, 25);
       clientNameTF.setSize(200, 30);
       clientIDTF.setSize(200, 30);
   
       
       
        Container pane = getContentPane();
        pane.setLayout(null);
 
        pane.add(stock100);
        pane.add(stock200);
        pane.add(stock300);
        pane.add(resultButton);
        pane.add(totalInvestment);
        pane.add(resultTA);
        pane.add(clientID);
        pane.add(clientName);
        pane.add(clientStock);
        pane.add(clientPrice);
        pane.add(priceUnit);
        pane.add(clientNameTF);
        pane.add(clientIDTF);
        

        
        setTitle("Client Investment Application");
        setSize(600,560);
        setVisible(true);
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);       
    }
    
    
    
    
    public static void main(String[] args)  {

        TestClientBanking test = new TestClientBanking();
    
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getActionCommand().equals("Calculate"))
            {
                clientIDI = Integer.parseInt(clientIDTF.getText());
                clientNameI = clientNameTF.getText();
                
                Client yourClient = new Client(clientIDI, clientNameI, clientStUnitI, clientStPriceI);
                
                String output;
                output = "Client ID: " + yourClient.getClient_id() + "\n" +
                        "Client name: " + yourClient.getClient_name()  + "\n" +
                        "Client stock units: " + yourClient.getClient_StUnit()  + "\n" +
                        "Client stock price: " + yourClient.getClient_StPrice()  + "\n" +
                        "Client Total investment: " + yourClient.CalculateClientInvestment()  + "$"; 
                resultTA.append(output);
                
 
            }
 
     }

    @Override
    public void itemStateChanged(ItemEvent ie) {
        
                if((ie.getSource() == stock100))
                    {
                if(stock100.isSelected() == true)
                  {
                      clientStUnitI = 100;
                  }
                    }
                
                if((ie.getSource() == stock200))
                    {
                if(stock200.isSelected() == true)
                  {
                      clientStUnitI = 200;
                  }    
                    }
                
                if((ie.getSource() == stock300))
                    {
                if(stock300.isSelected() == true)
                  {
                      clientStUnitI = 300;
                  }        
                    }
                                       
                   
        
       if((ie.getSource() == priceUnit))
                    {
                        
                        clientStPriceI = Double.parseDouble(prices[priceUnit.getSelectedIndex()]);                        
                    }                       
 
                
     }

  
}
