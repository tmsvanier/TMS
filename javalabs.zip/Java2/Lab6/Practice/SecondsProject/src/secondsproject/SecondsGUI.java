package secondsproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SecondsGUI implements ActionListener 
    
{ 
    JTextField yearTF,numberYearTF,numbeWeeksTF,numberHourTF,numberDayTF,numberMinutesTF,numberSecondsTF;

   public SecondsGUI()
   {
         JButton calculateB, exitB,resetB;
         
         JFrame wframe=new JFrame();
         wframe.setTitle("Conversion of seconds");
         
         JLabel yearL,numberYearL,numbeWeeksL,numberHourL,numberDayL,numberMinutesL,numberSecondsL;
        

        yearL=new JLabel("Enter the number of seconds: ",SwingConstants.RIGHT);
        numberYearL=new JLabel("Number of years: ",SwingConstants.RIGHT);
        numbeWeeksL=new JLabel("Number of weeks: ",SwingConstants.RIGHT);
        numberDayL=new JLabel("Number of days: ",SwingConstants.RIGHT);
        numberHourL=new JLabel("Number of hours: ",SwingConstants.RIGHT);
        numberMinutesL=new JLabel("Number of minutes: ",SwingConstants.RIGHT);
        numberSecondsL=new JLabel("Number of seconds: ",SwingConstants.RIGHT);             

         yearTF= new JTextField(10);
         numberYearTF= new JTextField(10);
         numberYearTF.setEditable(false);
         numbeWeeksTF= new JTextField(10);
         numbeWeeksTF.setEditable(false);
         numberHourTF= new JTextField(10);
         numberHourTF.setEditable(false);
         numberDayTF= new JTextField(10);
         numberDayTF.setEditable(false);
         numberMinutesTF= new JTextField(10);
         numberMinutesTF.setEditable(false);
         numberSecondsTF= new JTextField(10);
         numberSecondsTF.setEditable(false);

        calculateB=new JButton("Calculate");
         exitB=new JButton("Exit");
         resetB=new JButton("Reset");

        calculateB.addActionListener(this);     
        resetB.addActionListener(this);      
        exitB.addActionListener(this);
       
         
        Container pane=wframe.getContentPane();

        pane.setLayout(new GridLayout(9,2));

        wframe.setSize(400,300);
        wframe.setVisible(true);
        
        pane.add(yearL);
        pane.add(yearTF);
        pane.add(numberYearL);
        pane.add(numberYearTF);
        pane.add(numbeWeeksL);
        pane.add(numbeWeeksTF);
        pane.add(numberDayL);
        pane.add(numberDayTF);
        pane.add(numberHourL);
        pane.add(numberHourTF);
        pane.add(numberMinutesL);
        pane.add(numberMinutesTF);
        pane.add(numberSecondsL);
        pane.add(numberSecondsTF);
        pane.add(calculateB);
        pane.add(exitB);
        pane.add(resetB); 
        
    } 
   
    public void actionPerformed(ActionEvent e)
    {
        if (e.getActionCommand().equals("Calculate"))
            {
                long temp=0;
                temp=Long.parseLong(yearTF.getText());
                numberYearTF.setText(""+(long) temp/31536000);
                temp=temp%31536000;
                numbeWeeksTF.setText(""+(long)(temp/604800));
                temp=temp%604800;
                numberDayTF.setText(""+(long)(temp/86400));
                temp=temp%86400;
                numberHourTF.setText(""+(long)(temp/3600));
                temp=temp%3600;
                numberMinutesTF.setText(""+(long)(temp/60));
                temp=temp%60;
                numberSecondsTF.setText(""+ temp);
                
            }
        if (e.getActionCommand().equals("Exit"))
            {
                System.exit(0);
            }
        if (e.getActionCommand().equals("Reset"))
            {
                numberYearTF.setText("");
                numberDayTF.setText("");
                numberHourTF.setText("");
                numberMinutesTF.setText("");
                numberSecondsTF.setText("");
                numbeWeeksTF.setText("");
                yearTF.setText("");
            
            }
    }          
}
