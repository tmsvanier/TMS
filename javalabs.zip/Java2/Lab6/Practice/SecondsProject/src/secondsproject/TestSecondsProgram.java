package secondsproject;

public class TestSecondsProgram {
    public static void main(String[] args)
    {
        SecondsGUI secondProgram=new SecondsGUI();
    }    
}
