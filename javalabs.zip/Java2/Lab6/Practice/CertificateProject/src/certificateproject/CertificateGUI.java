package certificateproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CertificateGUI implements ActionListener 
{
    JTextField numberYearTF,amountDepositTF,interestRrateTF,certificateMaturityTF;

    public CertificateGUI()
    {
          JButton CalculateB, exitB,resetB;
          JFrame wframe=new JFrame();
          wframe.setTitle("Certificate of deposit");
          JLabel numberYearL,amountDepositL,interestRrateL,certificateMaturityL;

          amountDepositL=new JLabel("Amount deposited: ",SwingConstants.RIGHT);
          numberYearL=new JLabel("Years: ",SwingConstants.RIGHT);
          interestRrateL=new JLabel("interest rate: ",SwingConstants.RIGHT);
          certificateMaturityL=new JLabel("The amount of a certificate of deposit on maturity: ",SwingConstants.RIGHT);

          amountDepositTF= new JTextField(10);
          numberYearTF= new JTextField(10);         
          interestRrateTF= new JTextField(10);        
          certificateMaturityTF= new JTextField(10);
          certificateMaturityTF.setEditable(false);

          CalculateB=new JButton("Calculate");
          exitB=new JButton("Exit");
          resetB=new JButton("Reset");

         CalculateB.addActionListener(this);     
         resetB.addActionListener(this);      
         exitB.addActionListener(this);

         Container pane=wframe.getContentPane();

         pane.setLayout(new GridLayout(6,2));
         pane.add(amountDepositL);
         pane.add(amountDepositTF);
         pane.add(numberYearL);
         pane.add(numberYearTF);
         pane.add(interestRrateL);
         pane.add(interestRrateTF);
         pane.add(certificateMaturityL);
         pane.add(certificateMaturityTF);        
         pane.add(CalculateB);
         pane.add(exitB);
         pane.add(resetB); 
         wframe.setSize(600,200);
         wframe.setVisible(true);
     } 
   
    public void actionPerformed(ActionEvent e)
    {
        if (e.getActionCommand().equals("Calculate"))
            {
                double tempdep=0,tempint=0,tempRate=0,temp=0;
                double tempYears=0;
                tempdep=Double.parseDouble(amountDepositTF.getText());              
                tempint=Double.parseDouble(interestRrateTF.getText());               
                tempYears=Double.parseDouble(numberYearTF.getText());
                temp=tempdep*Math.pow((1+tempint/100),tempYears);
                certificateMaturityTF.setText(String.format(" %.2f $",temp)); 
            }
        if (e.getActionCommand().equals("Exit"))
            {
                System.exit(0);
            }
        if (e.getActionCommand().equals("Reset"))
            {
                numberYearTF.setText("");
                amountDepositTF.setText("");
                interestRrateTF.setText("");
                certificateMaturityTF.setText("");   
            }
    }          
}
