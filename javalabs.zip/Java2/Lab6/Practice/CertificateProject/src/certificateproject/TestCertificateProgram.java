package certificateproject;
public class TestCertificateProgram {
    public static void main(String[] args)
        {
           CertificateGUI Depositprogram=new CertificateGUI();
        }
}
