package sportproject;
import java.io.FileNotFoundException;
public class TestSportprogram 
{
    public static void main(String[] args) throws FileNotFoundException
    {
        SportGUIinterface SportProgram=new SportGUIinterface();
    }
}
