package sportproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
public class SportGUIinterface implements ActionListener 
{
  
    JTextField NameTF,number_hourperWeekTF,number_WeeksTF,cost_per_hourTF,
            CostofSportTrainingTF,costmySport1TF,costmySport2TF,costmySport3TF,
            costofST_TF,costRecordSport1TF,costRecordSport2TF, costRecordSport3TF,costRecordSport4TF,costRecordSport5TF;
            
   
    Sport yourSport,mySport1,mySport2,mySport3,RecordSport1,RecordSport2,RecordSport3,RecordSport4,RecordSport5;
    
    
   Scanner inFile=new Scanner(new FileReader("Sport.in"));
      PrintWriter outFile=new PrintWriter("Sport.out");
   
      
    public SportGUIinterface()throws FileNotFoundException
    {
        JFrame wframe=new JFrame();

    JLabel NameL,number_hourperWeekL,number_WeeksL,cost_per_hourL,
            CostofSportTrainingL,costmySport1L,costmySport2L,costmySport3L,costofSTL,costRecordSport1L,
            costRecordSport2L,costRecordSport3L,costRecordSport4L,costRecordSport5L;

    JButton calculateB, exitB;
        
        yourSport=new Sport();
        mySport1=new Sport();
        mySport2=new Sport();
        mySport3=new Sport();
        RecordSport1=new Sport();
        RecordSport2=new Sport();
        RecordSport3=new Sport();
        RecordSport4=new Sport();
        RecordSport5=new Sport();
        NameL=new JLabel("Enter Name:",SwingConstants.RIGHT);
        number_hourperWeekL=new JLabel("Enter Number of Hours Per/Week: ",SwingConstants.RIGHT);
        number_WeeksL=new JLabel("Enter Number of Weeks of ST: ",SwingConstants.RIGHT);
        cost_per_hourL=new JLabel("Enter The Cost of ST per Hour: ",SwingConstants.RIGHT);
        CostofSportTrainingL=new JLabel("The Cost of ST(your Sport Object): ",SwingConstants.RIGHT);
        costmySport1L=new JLabel("The cost of ST(mySport1 object): ",SwingConstants.RIGHT);
        costmySport2L=new JLabel("The cost of ST(mySport2 object): ",SwingConstants.RIGHT);
        costofSTL=new JLabel("The cost of ST yourObject...myObject2: ",SwingConstants.RIGHT);
        costmySport3L=new JLabel("The cost of ST(mySport3 object): ",SwingConstants.RIGHT);
        costRecordSport1L=new JLabel("The cost of ST(RecordSport1 object): ",SwingConstants.RIGHT);
        costRecordSport2L=new JLabel("The cost of ST(RecordSport2 object): ",SwingConstants.RIGHT);
        costRecordSport3L=new JLabel("The cost of ST(RecordSport3 object): ",SwingConstants.RIGHT);
        costRecordSport4L=new JLabel("The cost of ST(RecordSport4 object): ",SwingConstants.RIGHT);
        costRecordSport5L=new JLabel("The cost of ST(RecordSport5 object): ",SwingConstants.RIGHT);
 
        NameTF=new JTextField(10);
        number_hourperWeekTF=new JTextField(10);
        number_WeeksTF=new JTextField(10);
        cost_per_hourTF=new JTextField(10);    
        CostofSportTrainingTF=new JTextField(10);        
        costmySport1TF=new JTextField(10);
        costmySport2TF=new JTextField(10);               
        costofST_TF=new JTextField(10);
        costmySport3TF=new JTextField(10);
        costRecordSport1TF=new JTextField(10);
        costRecordSport2TF=new JTextField(10);
        costRecordSport3TF=new JTextField(10);
        costRecordSport4TF=new JTextField(10);
        costRecordSport5TF=new JTextField(10);

       calculateB=new JButton("Calculate");

       calculateB.addActionListener(this);
       JButton ReadingFile=new JButton("Reading File");

       ReadingFile.addActionListener(this);
       JButton WritingFile=new JButton("Writing File");
       WritingFile.addActionListener(this);
       
       exitB=new JButton("Exit");
       exitB.addActionListener(this);
       
       wframe.setTitle("Sport Training Application");
       Container pane=wframe.getContentPane();
       
       pane.setLayout(new GridLayout(16,2));
    pane.add(NameL);
    pane.add(NameTF);
    pane.add(number_hourperWeekL);
    pane.add(number_hourperWeekTF);
    pane.add(number_WeeksL);   
    pane.add(number_WeeksTF);            
    pane.add(cost_per_hourL);
    pane.add(cost_per_hourTF);
    pane.add(CostofSportTrainingL);
    pane.add(CostofSportTrainingTF);
    pane.add(costmySport1L);
    pane.add(costmySport1TF);
    pane.add(costmySport2L);
    pane.add(costmySport2TF);
    pane.add(costofSTL);
    pane.add(costofST_TF);
    pane.add(costmySport3L);
    pane.add(costmySport3TF);
    pane.add(costRecordSport1L);
    pane.add(costRecordSport1TF);
    pane.add(costRecordSport2L);
    pane.add(costRecordSport2TF);
    pane.add(costRecordSport3L);
    pane.add(costRecordSport3TF);
    pane.add(costRecordSport4L);
    pane.add(costRecordSport4TF);
    pane.add(costRecordSport5L);
    pane.add(costRecordSport5TF);  
    pane.add(calculateB);
    pane.add(exitB);
    pane.add(ReadingFile);
    pane.add(WritingFile);
    wframe.setSize(500,400);
    wframe.setVisible(true);               
    }
 
    public void actionPerformed(ActionEvent e)
    {
        if (e.getActionCommand().equals("Calculate"))
            {
                mySport1.setName("Bob");
                mySport1.setNumber_hour(3);
                mySport1.setNumber_week(12);
                mySport2.setName("Irena");
                mySport2.setNumber_hour(17);
                mySport2.setNumber_week(52);
                yourSport.setName(NameTF.getText());
                yourSport.setNumber_hour(Double.parseDouble(number_hourperWeekTF.getText()));
                yourSport.setNumber_week(Integer.parseInt(number_WeeksTF.getText()));
                Sport.cost_hour=Double.parseDouble(cost_per_hourTF.getText());

                mySport3.makeCopy(yourSport);
                    CostofSportTrainingTF.setText(""+String.format(" %.2f $", yourSport.CalculateCostTraining()));
                    costmySport1TF.setText(""+String.format(" %.2f $", mySport1.CalculateCostTraining()));
                    costmySport2TF.setText(""+String.format(" %.2f $", mySport2.CalculateCostTraining()));
                    costofST_TF.setText(""+String.format(" %.2f $", (yourSport.CalculateCostTraining())
                                         +mySport1.CalculateCostTraining()+mySport2.CalculateCostTraining()));
                     costmySport3TF.setText(""+String.format(" %.2f $", mySport3.CalculateCostTraining()));
            }
        else if (e.getActionCommand().equals("Reading File"))
            {
                RecordSport1.setName(inFile.next()+" "+inFile.next());
                RecordSport1.setNumber_hour(inFile.nextDouble());
                RecordSport1.setNumber_week(inFile.nextInt());
                Sport.cost_hour=(inFile.nextDouble());

                costRecordSport1TF.setText(""+String.format(" %.2f $", 
                                              RecordSport1.CalculateCostTraining()));

                RecordSport2.setName(inFile.next()+" "+inFile.next());
                RecordSport2.setNumber_hour(inFile.nextDouble());
                RecordSport2.setNumber_week(inFile.nextInt());
                Sport.cost_hour=(inFile.nextDouble());

                costRecordSport2TF.setText(""+String.format(" %.2f $", 
                                              RecordSport2.CalculateCostTraining()));

                RecordSport3.setName(inFile.next()+" "+inFile.next());
                RecordSport3.setNumber_hour(inFile.nextDouble());
                RecordSport3.setNumber_week(inFile.nextInt());
                Sport.cost_hour=(inFile.nextDouble());

                costRecordSport3TF.setText(""+String.format(" %.2f $", 
                                              RecordSport3.CalculateCostTraining()));

                RecordSport4.setName(inFile.next()+" "+inFile.next());
                RecordSport4.setNumber_hour(inFile.nextDouble());
                RecordSport4.setNumber_week(inFile.nextInt());
                Sport.cost_hour=(inFile.nextDouble());

                costRecordSport4TF.setText(""+String.format(" %.2f $", 
                                              RecordSport4.CalculateCostTraining()));

                RecordSport5.setName(inFile.next()+" "+inFile.next());
                RecordSport5.setNumber_hour(inFile.nextDouble());
                RecordSport5.setNumber_week(inFile.nextInt());
                Sport.cost_hour=(inFile.nextDouble());

                costRecordSport5TF.setText(""+String.format(" %.2f $", 
                                              RecordSport5.CalculateCostTraining()));

            }
        
        else if (e.getActionCommand().equals("Writing File"))
         {
             outFile.println("RecordSport1\t"+RecordSport1.getName()+"\t"+RecordSport1.getNumber_hour()+"\t"+RecordSport1.getNumber_week()+"\t"+
                Sport.cost_hour+"\t"+String.format(" %.2f $",RecordSport1.CalculateCostTraining()));
             outFile.println("RecordSport2\t"+RecordSport2.getName()+"\t"+RecordSport2.getNumber_hour()+"\t"+RecordSport2.getNumber_week()+"\t"+
                Sport.cost_hour+"\t"+String.format(" %.2f $",RecordSport2.CalculateCostTraining()));
             outFile.println("RecordSport3\t"+RecordSport3.getName()+"\t"+RecordSport3.getNumber_hour()+"\t"+RecordSport3.getNumber_week()+"\t"+
                Sport.cost_hour+"\t"+String.format(" %.2f $",RecordSport3.CalculateCostTraining()));
             outFile.println("RecordSport4\t"+RecordSport4.getName()+"\t"+RecordSport4.getNumber_hour()+"\t"+RecordSport4.getNumber_week()+"\t"+
                Sport.cost_hour+"\t"+String.format(" %.2f $",RecordSport4.CalculateCostTraining()));
             outFile.println("RecordSport5\t"+RecordSport5.getName()+"\t"+RecordSport5.getNumber_hour()+"\t"+RecordSport5.getNumber_week()+"\t"+
                Sport.cost_hour+"\t"+String.format(" %.2f $",RecordSport5.CalculateCostTraining()));
             
             outFile.close();
         }
        
        else if (e.getActionCommand().equals("Exit"))
             System.exit(0);
        inFile.close();
        }
    
}
