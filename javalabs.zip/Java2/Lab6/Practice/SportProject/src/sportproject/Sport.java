package sportproject;


import java.util.Scanner;
public class Sport 
{
    private String Name;
    private double number_hour;
    private int number_week;
    public static double cost_hour;
    
    public Sport()
    {
        Name="";
        number_hour=0.00;
        number_week=0;
    }
    public Sport (String Sname, double Snumberhour,int SnumberWeek)
    {
        Name=Sname;
        number_hour=Snumberhour;
        number_week=SnumberWeek;
    }
    //Mutators
    public void setName(String Sname)
    {
         Name=Sname;
    }
    public void setNumber_hour(double SNhour)
    {
        number_hour=SNhour;
    }
    public void setNumber_week(int Sweek)
    {
          number_week=Sweek;
    }
    public String getName()
    {
        return Name; 
    }
    public double getNumber_hour()
    {
        return number_hour;
    }
    public int getNumber_week()
    {
          return number_week;
    }
    public double CalculateCostTraining()
    {
        double cost_training = cost_hour * number_hour * number_week;
        return cost_training;
        
    }
    public String toString()
    {
        return "//"+Name+"//"+number_hour+"//"+number_week+"//"+cost_hour+"$";
    }
    public void makeCopy(Sport Wsport)
    {
        Name=Wsport.getName();
        number_hour=Wsport.number_hour;
        number_week=Wsport.getNumber_week();
    }
    public static Sport doSearch(Scanner inFile, String byName)
    {
        Sport Sportfound=new Sport();
        String name;
        double a,b;
        int c;
        boolean found=false;
        while (inFile.hasNextLine())
          {
            name=inFile.next()+" "+inFile.next();
            
             a=inFile.nextDouble();
             c=inFile.nextInt();
             b=inFile.nextDouble();
             if(name.equals(byName))
             {
                 Sportfound.Name=name;
                 Sportfound.number_hour=a;
                 Sportfound.number_week=c;
                 Sport.cost_hour=b;
                 found=true;
                 break;
             }                            
           }
       if(found!=true) { Sportfound=null; }
        return Sportfound;
    }
    
}
