 
package exceptionlogfileproject;
import java.util.*;
import java.io.*;
public class TestExceptionLogFile {
 

static Scanner console = new Scanner(System.in);



    public static void main(String[] args) throws  IOException {
PrintWriter   logFile = new PrintWriter ("logFile.out");
              int dividend, divisor, quotient;
        boolean done = false;
        Date date = new Date();
 
        
        do {
            
        
        
            try
                    {

                        
                        
                    System.out.println("Line 4: Enter the dividend: ");

                    dividend=console.nextInt();
                    
                    System.out.println("Line 7: Enter the divisor: ");
                    divisor=console.nextInt();
                    
                    System.out.println();
                    
                    quotient = dividend/divisor;

                    System.out.println("Line 11: Quotient] = " + quotient);
  
                    done = true;
                    logFile.close();
                    }
            
                    catch(ArithmeticException aeRef)
                    {
                    System.out.println("Line 13: Exception: " + aeRef.toString());
                    logFile.printf("Exception occurred: %s on %tD at %tc\n" , aeRef.toString(), date, date);
                     
                    }
            
                    catch(InputMismatchException imeRef)
                    {
                    String divisortemp=console.next();
                    System.out.println("Line 15: Exception: " + imeRef.toString()+": " + divisortemp);
                    logFile.printf("Exception occurred: %s: %s on %tD at %tc\n" , imeRef.toString(), divisortemp, date, date);
                                        
                    }               
        
        }
        while(!done);
    }
    }
    