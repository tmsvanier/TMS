
package sportproject;


    public class Equipment 
{
    private String equiTitle;
    private double equiPrice;

    public Equipment() {
        equiTitle ="##";
        equiPrice = 0.0;
    }
    public Equipment(String equiTitle, double equiPrice) {
        this.equiTitle = equiTitle;
        this.equiPrice = equiPrice;
    }

    public String getEquiTitle() {
        return equiTitle;
    }

    public void setEquiTitle(String equiTitle) {
        this.equiTitle = equiTitle;
    }

    public double getEquiPrice() {
        return equiPrice;
    }

    public void setEquiPrice(double equiPrice) {
        this.equiPrice = equiPrice;
    }
}
