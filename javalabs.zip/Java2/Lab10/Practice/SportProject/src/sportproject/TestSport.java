
package sportproject;

import java.util.*;
public class TestSport 
{
    static Scanner console=new  Scanner(System.in);
    
    public static void main(String[] args)
    {
        
        
         Sport myPlayer=new Sport();
         
         myPlayer.setName("bob");
         myPlayer.setNumberHour(3);
         myPlayer.setNumberWeek(15);
         Sport.costHour=15;
         System.out.println("Enter the First Name,Number of Hour and cost of an hour of traing:\n"
                  +  "The Sport Traing Aplication Built with Object Oriented Programming (OPP)\n\n");
         

          Sport yourPlayer=new Sport("Irena",4,25);
          System.out.println("Info of myPlayer:\nThe Sport Training Information is: " + myPlayer);
          System.out.println("\n\nInfo of yourPlayer:\nThe Sport Training Information is: " + yourPlayer);
          
          boolean done = false;
          
        do {
            
 
            try
                    {
                        System.out.println("\n\n");
                        System.out.print("Enter Name: ");
                        yourPlayer.setName(console.next());
 
                        System.out.print("Enter Number of Sport Training Hour Per Week: ");
                        yourPlayer.setNumberHour(console.nextDouble());
                            if(yourPlayer.getNumberHour()<0)
                                throw new MyArithmeticException();
                            
                        System.out.print("Enter Number of weeks of Sport: ");
                        yourPlayer.setNumberWeek(console.nextInt());
                            if(yourPlayer.getNumberWeek()<0)
                                throw new MyArithmeticException();         
                            
                        System.out.print("Enter The Cost of Sport Training per hour: ");
                        Sport.costHour=console.nextDouble();
                            if(Sport.costHour<0)
                                throw new MyArithmeticException();                           
 
                        done = true;
                    }
           
            catch(Exception eRef)
                    {
                        if(eRef instanceof InputMismatchException)
                            {
                                String temp = console.next();
                                System.out.println("Line 16: Exception: " + eRef.toString() + ": " + temp);
                            }  
                        else if(eRef instanceof MyArithmeticException)
                            {
                               System.out.println("Exception occured: " + eRef.toString());
                            }
                    }
            
        }
        while(!done);

           
           System.out.println("\n\nInfo of yourPlayer:\nThe new Sport Training Information is: " + yourPlayer);
           
           
           ChildSport mychildPlayer=new ChildSport("Fares",2,10,6);
           ChildSport yourchildPlayer=new ChildSport("Samantha",2,18,7);
           
          System.out.println("Info of mychildPlayer:\nThe Sport Training Information is: " + mychildPlayer);
          
           System.out.println("Info of yourchildPlayer:\nThe Sport Training Information is: " + yourchildPlayer);
           
           
            yourPlayer=yourchildPlayer;
            System.out.println("Polymorphism: Invoking Subclass method with superclass object reference: " + yourPlayer.CalculateCostTraining());
            
            System.out.println("Calling method defined in interface SecondarySport SumPro return: " + yourchildPlayer.SumPro());
           
            System.out.println("Using Compositon, The Equipment Title : Apparatus For Body Building ");

           
            yourchildPlayer.myequipment.setEquiTitle("Appartus For Body Building ");
            yourchildPlayer.myequipment.setEquiPrice(120);
            
            System.out.println("\n\nAfter setting myequipment object as an data membe for your childPlayer :\nEquipment Title is : " + yourchildPlayer.myequipment.getEquiTitle()
             + "\nEquipment price is: " + yourchildPlayer.myequipment.getEquiPrice() + "$");
            
            
    }
    
}
