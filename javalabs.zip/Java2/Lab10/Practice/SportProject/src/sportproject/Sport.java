
package sportproject;


import java.util.Scanner;
public class Sport 
{
    private String Name;
    private double numberHour;
    private int numberWeek;
    public static double costHour;
    
 
    public Sport()
    {
        Name = "";
        numberHour = 0.00;
        numberWeek = 0;
    }
    public Sport (String Sname, double Snumberhour,int SnumberWeek)
    {
        Name = Sname;
        numberHour = Snumberhour;
        numberWeek = SnumberWeek;
    }
 
    public void setName(String Sname)
    {
         Name = Sname;
    }
    public void setNumberHour(double SNhour)
    {
        numberHour = SNhour;
    }
    public void setNumberWeek(int Sweek)
    {
          numberWeek = Sweek;
    }
 
    public String getName()
    {
        return Name; 
    }
    public double getNumberHour()
    {
        return numberHour;
    }
    public int getNumberWeek()
    {
          return numberWeek;
    }
    
 
    public double CalculateCostTraining()
    {
        double costTraining  =  costHour * numberHour * numberWeek;
        return costTraining;
        
    }
    public String toString()
    {
        return "//" + Name + "//" + numberHour + "//" + numberWeek + "//" + costHour + "$";
    }
 
    public void makeCopy(Sport Wsport)
    {
        Name = Wsport.getName();
        numberHour = Wsport.numberHour;
        numberWeek = Wsport.getNumberWeek();
    }
    
 
    public static Sport doSearch(Scanner inFile, String byName)
    {
        
        
        Sport Sportfound = new Sport();
        
        String name;
        double a,b;
        int c;
        boolean found = false;
        while (inFile.hasNextLine())
          {
            name = inFile.next() + " " + inFile.next();
            
             a = inFile.nextDouble();
             c = inFile.nextInt();
             b = inFile.nextDouble();
             if(name.equals(byName))
             {
                 Sportfound.Name = name;
                 Sportfound.numberHour = a;
                 Sportfound.numberWeek = c;
                 Sport.costHour = b;
                 found = true;
                 break;
             }                            
           }
       if(found!=true) 
           Sportfound = null;
        return Sportfound;
    }
    
}
