 
package sportproject;

 
public class MyArithmeticException extends Exception {
    public MyArithmeticException()
    {
        super("Negative values are not allowed");
    }
    
}
