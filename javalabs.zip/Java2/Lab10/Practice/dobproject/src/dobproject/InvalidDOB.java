
package dobproject;


public class InvalidDOB extends Exception {
    
    InvalidDOB() {
                super("Invalid DOB string, please enter 10 symbols in the following format: mm-dd-yyyy!");
                
    }
}
