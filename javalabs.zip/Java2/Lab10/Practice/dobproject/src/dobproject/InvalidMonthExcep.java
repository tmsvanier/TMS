
package dobproject;


public class InvalidMonthExcep extends Exception {
    
    InvalidMonthExcep() {
                super("Incorrect input, please enter valid month (1-12).");
    }
}
