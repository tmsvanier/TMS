
package dobproject;


public class InvalidDayExcep extends Exception {
    
    InvalidDayExcep() {
                super("Incorrect input, please enter valid day."
                       + "\n\n--------------------------------------\n"
                            + "Number of days in the months:\n"
                            + "January - 31 days\n" +
                            "February - 28 days (29 in Leap Years)\n" +
                            "March - 31 days\n" +
                            "April - 30 days\n" +
                            "May - 31 days\n" +
                            "June - 30 days\n" +
                            "July - 31 days\n" +
                            "August - 31 days\n" +
                            "September - 30 days\n" +
                            "October - 31 days\n" +
                            "November - 30 days\n" +
                            "December - 31 days"
                            + "\n--------------------------------------\n");
                
    }
}
