package bankingproject;

public interface  BankingAccount
{
    public double AddAmount(double Amount);    
    public double withdrawAmount(double Amount);

}
