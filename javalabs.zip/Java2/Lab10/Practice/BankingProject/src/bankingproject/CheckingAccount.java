package bankingproject;

public class CheckingAccount implements BankingAccount
{
    private int clientID;
    private String  clientName;
    private double  clientTotalAmount;

    public CheckingAccount() 
    {
        clientID = 0;
        clientName = "";
        clientTotalAmount = 0.00;
    }

    public CheckingAccount(int clientID, String clientName, double clientTotalAmount) 
    {
        this.clientID = clientID;
        this.clientName = clientName;
        this.clientTotalAmount = clientTotalAmount;
    }

    public int getClient_ID() {
        return clientID;
    }

    public void setClient_ID(int clientID) {
        this.clientID = clientID;
    }

    public String getClient_Name() {
        return clientName;
    }

    public void setClient_Name(String clientName) {
        this.clientName = clientName;
    }

    public double getClient_Total_Amount() {
        return clientTotalAmount;
    }

    public void setClient_Total_Amount(double clientTotalAmount) {
        this.clientTotalAmount = clientTotalAmount;
    }

    @Override
    public String toString() {
        return "//" + clientID + "//" + clientName + "//" + clientTotalAmount;
    }
    public  double AddAmount(double Amount)
    {
        clientTotalAmount += Amount;
        return clientTotalAmount;
    }
    public  double withdrawAmount(double Amount)
    {
        clientTotalAmount -= Amount;
        return clientTotalAmount;
    }
    public void printInfo()
    {
        System.out.printf("%nThe information of this object is %n\tClient Id: %5d%n\tClient name: %s%n\tclient total Amount:"
                  + " %.2f $%n",clientID,clientName,clientTotalAmount);
    }
    
}
