package bankingproject;


import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class BankGInterface extends CheckingAccount implements ActionListener
{
    
   JTextField clientIDTF, clientNameTF, clientTotalAmountTF, AmountAddingTF, AmountWithdrawingTF, savingAccountTF, investmentAccountTF;
   CheckingAccount myAccount;
   SavingAccount SavingAccount;
   InvestmentAccount myInvestmentAccount;
   
   
    public BankGInterface() 
    {        
       super();       
       myAccount=new CheckingAccount();
       SavingAccount=new SavingAccount(105, "benet", 0, 1.5, 1500);
       myInvestmentAccount=new InvestmentAccount(115, "Sarah", 0,  1.5,  4000);
 
         JFrame wframe=new JFrame();
         wframe.setTitle("Banking Application ");
 
         JLabel clientIDL, clientNameL, clientTotalAmountL, AmountAddingL, AmountWithdrawingL, savingAccountL, investmentAccountL;
         
 
        clientIDL=new JLabel("Enter Clinet Id:", SwingConstants.RIGHT);
        clientNameL=new JLabel("Enter Clinet Name:", SwingConstants.RIGHT);
        AmountAddingL=new JLabel("Enter Clinet Deposit Amount:", SwingConstants.RIGHT);
        AmountWithdrawingL=new JLabel("Enter Clinet withdraw amount:", SwingConstants.RIGHT);
        clientTotalAmountL=new JLabel("The client Balance:", SwingConstants.RIGHT);
        savingAccountL=new JLabel("The client Saving Account:", SwingConstants.RIGHT);
        investmentAccountL=new JLabel("The client Investment Account:", SwingConstants.RIGHT);
       
      
         clientIDTF= new JTextField(10);
         clientNameTF= new JTextField(10);
         AmountAddingTF= new JTextField(10);
         AmountWithdrawingTF= new JTextField(10);
         clientTotalAmountTF= new JTextField(10);
         savingAccountTF= new JTextField(10);
         investmentAccountTF=new JTextField(10);
         
 
         JButton BalanceB,  exitB, savingaccountB, investmentB, addSavingB, addInvestmentB;
         BalanceB=new JButton("Balance");
         savingaccountB=new JButton("Saving Account");
         investmentB=new JButton("Investment Account");
         addSavingB=new JButton("Add Saving Amount");
         addInvestmentB=new JButton("Add Investment Amount");         
         exitB=new JButton("Exit");
         
 
         BalanceB.addActionListener(this);
         exitB.addActionListener(this);
         savingaccountB.addActionListener(this);
         investmentB.addActionListener(this);
         addSavingB.addActionListener(this);
         addInvestmentB.addActionListener(this);
         
          
        Container pane=wframe.getContentPane();
 
        pane.setLayout(new GridLayout(10, 2));
 
         wframe.setSize(400, 400);
        wframe.setVisible(true);
        
 
        pane.add(clientIDL);        
        pane.add(clientIDTF);
        pane.add(clientNameL);
        pane.add(clientNameTF);
        pane.add(AmountAddingL);
        pane.add(AmountAddingTF);
        pane.add(AmountWithdrawingL);
        pane.add(AmountWithdrawingTF);
        pane.add(clientTotalAmountL);
        pane.add(clientTotalAmountTF);
        pane.add(savingAccountL);
        pane.add(savingAccountTF);
        pane.add(investmentAccountL);
        pane.add(investmentAccountTF);        
        pane.add(BalanceB);
        pane.add(exitB);
        pane.add(savingaccountB);
        pane.add(investmentB);
        pane.add(addSavingB);
        pane.add(addInvestmentB);
 
        AmountAddingTF.setText(""+0.00);
        AmountWithdrawingTF.setText(""+0.00);
        
    }
    public void actionPerformed(ActionEvent e)
    {
        if (e.getActionCommand().equals("Balance"))
            {
                
               double decision1, decision2;
               
 
                myAccount.setClient_ID(Integer.parseInt(clientIDTF.getText()));
                myAccount.setClient_Name(clientNameTF.getText());
 
                decision1=Double.parseDouble(AmountAddingTF.getText());
                decision2=Double.parseDouble(AmountWithdrawingTF.getText());                                
                
 
                if(decision1!=0.00)
                {
                  clientTotalAmountTF.setText(""+ String.format("%.2f $", super.AddAmount(decision1)));
                  myAccount.setClient_Total_Amount(super.getClient_Total_Amount());
                }
 
                else if(decision2!=0.00)
                {
                  clientTotalAmountTF.setText(""+ String.format("%.2f $", super.withdrawAmount(decision2)));                    
                   myAccount.setClient_Total_Amount(super.getClient_Total_Amount());
                } 
                System.out.println("\n**After setting data for myaccount object**");             
                myAccount.printInfo();
            }
        if (e.getActionCommand().equals("Exit"))
            {
            System.exit(0);
            } 
        if (e.getActionCommand().equals("Saving Account"))
            {
                
               double decision1, decision2;
                        
 
                decision1=Double.parseDouble(AmountAddingTF.getText());
                decision2=Double.parseDouble(AmountWithdrawingTF.getText());
                clientIDTF.setText(""+SavingAccount.getClient_ID());
                clientNameTF.setText(""+SavingAccount.getClient_Name());
                 savingAccountTF.setText(""+ String.format("%.2f $", SavingAccount.getSavingAmount()));
                
 
                if(decision1!=0.00)
                {
                    
                  savingAccountTF.setText(""+ String.format("%.2f $", SavingAccount.AddAmount(decision1)));
                  SavingAccount.setSavingAmount(SavingAccount.AddAmount(decision1));
                }
 
                else if(decision2!=0.00)
                {
                  savingAccountTF.setText(""+ String.format("%.2f $", SavingAccount.withdrawAmount(decision2)));
                  SavingAccount.setSavingAmount(SavingAccount.withdrawAmount(decision2));
                }         
        
             System.out.println("\n**After setting data for myAccount object**");
             
             SavingAccount.printInfo();
        
           } 
        
          if (e.getActionCommand().equals("Investment Account"))
            {
 
                clientIDTF.setText(""+myInvestmentAccount.getClient_ID());
                clientNameTF.setText(""+myInvestmentAccount.getClient_Name());
 
                  investmentAccountTF.setText(""+ String.format("%.2f $", myInvestmentAccount.getInvestmentAmmount()));
 
                  System.out.println("\n**After setting data for myinvestment object**");
             
                myInvestmentAccount.printInfo();
                }
 
            if(e.getActionCommand().equals("Add Saving Amount"))
            {
                String str;
                 double addSaving;
                 str=JOptionPane.showInputDialog(null, "Please input your added saving Amount", 
                         "Saving Amount",  JOptionPane.INFORMATION_MESSAGE);
                 addSaving=Double.parseDouble(str); 

                 myAccount=SavingAccount;

                 savingAccountTF.setText(""+ String.format("%.2f $", myAccount.AddAmount(addSaving)));
                 clientIDTF.setText(""+myAccount.getClient_ID());
                 clientNameTF.setText(""+myAccount.getClient_Name());
 
                 System.out.println("\nAfter setting data for SavingAcount object");             
                 myAccount.printInfo();                                                   
            }
            
  
            if(e.getActionCommand().equals("Add Investment Amount"))
            {
                String str;
                 double addinvest;
                 str=JOptionPane.showInputDialog(null, "Please input your added Investment Amount", 
                         "Investment Amount",  JOptionPane.INFORMATION_MESSAGE);
                 addinvest=Double.parseDouble(str);
                 
 
                 myAccount=myInvestmentAccount;
 
                 investmentAccountTF.setText("" + String.format("%.2f $",  myAccount.AddAmount(addinvest)));
                 
                 clientIDTF.setText("" + myAccount.getClient_ID());
                clientNameTF.setText("" + myAccount.getClient_Name());
 
                 System.out.println("\nAfter setting data for SavingAcount object");             
                 myAccount.printInfo();                                                   
            }
             
        
          
        
    }
     
}
