package number15page637project;


import java.util.*;

import java.io.*;
import java.util.*;

public class TestNumber15page637
{
	static Scanner console = new Scanner(System.in);
        static Scanner inFile;
	public static void main(String[] args) throws FileNotFoundException, IOException 
	{
	       inFile=new Scanner(new FileReader("flightseats.in"));
		String[][] seatPlan = new String[13][6];
		char response;
	
		initializeSeatPlan(seatPlan);
		showMenu(seatPlan);
	
		System.out.println("To reserve a seat enter Y/y(Yes), N/n(No): ");
		response = console.next().charAt(0);
		System.out.println();
	
		while(response == 'y' || response == 'Y')
		{
			assignSeat(seatPlan);
			showMenu(seatPlan);
			System.out.println("Reserve another seat Y/y(Yes), N/n(No): ");
			response = console.next().charAt(0);
			System.out.println(); 
		}
	}//end of main
	// initialize seats with data file
	public static void initializeSeatPlan(String[][] sPlan) throws FileNotFoundException
	{
            inFile=new Scanner(new FileReader("flightseats.in"));
		int i, j;

		for(i = 0; i < sPlan.length; i++)
			for(j = 0; j < sPlan[0].length; j++)
				sPlan[i][j] =inFile.next();
	}
// show seats
	public static void showSeatAssignments(String[][] sPlan)
	{
		int i, j;

		System.out.println("          A B C  D E F");

		for(i = 0; i < sPlan.length; i++)
		{
			if(i < 9)
				System.out.printf("Row%4d   ",(i+1));
			else
				System.out.printf("Row%4d   ",(i+1));

				for(j = 0; j < sPlan[0].length; j++)
				{
					System.out.print(sPlan[i][j] + " ");
					
					if(j == 2)
						System.out.print(" ");
				}
				System.out.println();
		}

		System.out.println("* -- available seat");
		System.out.println("X -- occupied seat");
		System.out.println();
	}

	public static void assignSeat(String[][] sPlan)
	{
               String Str;
		char ticketType;
		char response;

		System.out.print("Enter ticket type:\nF/f (first class)\nB/b (Business class)\n"
				+"E/e (Economy class): ");
		Str = console.next();Str=Str.toUpperCase();
                ticketType=Str.charAt(0);
		System.out.println();

		switch(ticketType)
		{		
		case 'F': 
			if(!isFirstClassFull(sPlan))
				assignFirstClassSeat(sPlan);
			else
			{
				System.out.println("No first class seats are available");
				System.out.print("Press Y/y to continue: ");
				response = console.next().charAt(0);
				System.out.println();
			}
			break;
                case 'B': 
			if(!isBusinessClassFull(sPlan))
				assignBusinessClassSeat(sPlan);
			else
			{
				System.out.println("No Business class seats are available");
				System.out.print("Press Y/y to continue: ");
				response = console.next().charAt(0);
				System.out.println();
			}
			break;
		
		case 'E': 
			if(!isBusinessClassFull(sPlan) ||!isEconomicFull(sPlan))
				AssignEconomicClass(sPlan);
			else
			{
				System.out.println("No economy class seats are available");
				System.out.print("Press Y/y to continue: ");
				response = console.next().charAt(0);
				System.out.println();
			}
		}

//		showSeatAssignments(sPlan);
	}
//
	public static void showMenu(String[][] sPlan)
	{
		System.out.println("The current seat assignments is as follows.");
		showSeatAssignments(sPlan);
		System.out.println("Rows 1 and 2 are for first class passengers");
		System.out.println("Rows 3 through 7 are Business Class");
                System.out.println("Rows 8 through 13 are Econonic Class");
	}
//
	
   // ****************** select seat numbers**************************
   
               //assign first class
	public static void assignFirstClassSeat(String[][] sPlan) 
	{
		int rownumber;String Str;
		char columnNo;
						
		if(!isFirstClassFull(sPlan))
		{
                    
                    System.out.print("Enter Row number 1 - 2 : ");
                    rownumber = console.nextInt()-1;
                    System.out.print("Enter seat number (A - F): ");
                    Str = console.next();Str=Str.toUpperCase();
                    columnNo = Str.charAt(0);                    
                     AssignseatinArray(sPlan,rownumber,columnNo);
                    
		}
		else
			System.out.println("Sorry!!! First Class is Full");
	}
        
        
        public static void assignBusinessClassSeat(String[][] sPlan) 
	{
		int rownumber;
                String Str;
		char columnNo;
						
		if(!isBusinessClassFull(sPlan))
		{                    
                    System.out.print("Enter Row number 3 - 7 :");
                    rownumber = console.nextInt()-1;
                    System.out.print("Enter seat number (A - F): ");
                    Str = console.next();Str=Str.toUpperCase();
                    columnNo = Str.charAt(0);
                     AssignseatinArray(sPlan,rownumber,columnNo);                    
		}
		else
			System.out.println("Sorry!!! Business Class is Full");
	}

        

	public static void AssignEconomicClass(String[][] sPlan)
	{
		int rownumber;
                String Str;
		char columnNo;
		
		if(!isEconomicFull(sPlan))
		{
			System.out.print("Enter Row number 8 - 13 :");
                    rownumber = console.nextInt()-1;
                    System.out.print("Enter seat number (A - F): ");
                    Str = console.next();Str=Str.toUpperCase();
                    columnNo = Str.charAt(0);
                     AssignseatinArray(sPlan,rownumber,columnNo);                    
		}
		else
			System.out.println("Sorry!!! Economic Class is Full");
	}
        
        public static void AssignseatinArray(String[][] splan,int trwo,char tcolumn)
        {
           
            switch (tcolumn)
            {
                case('A'):
                {
                    if ( splan[trwo][0].equals("X"))
                    {
                       System.out.println("****This seat is occupied!!***");
                        break;
                    }
                  splan[trwo][0]="X";
                   showSeatAssignments(splan);
                  System.out.println("your Location is : Row "+(trwo+1)+" seat: "+tcolumn);
                System.out.println("This seat is reserved for you");
                break;                   
                }
                case('B'):
                {
                     if ( splan[trwo][1].equals("X"))
                    {
                        System.out.println("****This seat is occupied!!***");
                        break;
                    }
                  splan[trwo][1]="X";
                   showSeatAssignments(splan);
                  System.out.println("your Location is : Row "+(trwo+1)+" seat: "+tcolumn);
                  System.out.println("This seat is reserved for you");
                 break; 
                }
              case('C'):
                {
                     if ( splan[trwo][2].equals("X"))
                    {
                        System.out.println("****This seat is occupied!!***");
                        break;
                    }
                  splan[trwo][2]="X"; 
                   showSeatAssignments(splan);
                  System.out.println("your Location is : Row "+(trwo+1)+" seat: "+tcolumn);
                  System.out.println("This seat is reserved for you");                  
                  break; 
                }
                case('D'):
                {
                    if ( splan[trwo][3].equals("X"))
                    {
                       System.out.println("****This seat is occupied!!***");
                        break;
                    }
                  splan[trwo][3]="X"; 
                   showSeatAssignments(splan);
                  System.out.println("your Location is : Row "+(trwo+1)+" seat: "+tcolumn);
                  System.out.println("This seat is reserved for you");
                  break;
                }
                case('E'):
                {
                    if (splan[trwo][4].equals("X"))
                    {
                       System.out.println("****This seat is occupied!!***");
                        break;
                    }
                  splan[trwo][4]="X"; 
                   showSeatAssignments(splan);
                  System.out.println("your Location is : Row "+(trwo+1)+" seat: "+tcolumn);
                  System.out.println("This seat is reserved for you");
                  break;
                }
                case('F'):
                {
                     if (splan[trwo][5].equals("X"))
                    {
                        System.out.println("****This seat is occupied!!***");
                        break;
                    }
                  splan[trwo][5]="X"; 
                   showSeatAssignments(splan);
                  System.out.println("your Location is : Row "+(trwo+1)+" seat: "+tcolumn);
                  System.out.println("This seat is reserved for you");
                  break; 
                }     
            }
              
        }
        
        public static boolean isFirstClassFull(String[][] sPlan)
	{
		int i, j;

		int assignedSeats = 0;

		for(i = 0; i < 2; i++)
			for(j = 0; j < sPlan[0].length; j++)
				if(sPlan[i][j].equals("X"))
					assignedSeats++;

		return (assignedSeats == 2 * sPlan[0].length);
	}
//
	public static boolean isBusinessClassFull(String[][] sPlan)
	{
		int i, j;

		int assignedSeats = 0;

		for(i = 2; i < 7; i++)
			for(j = 0; j < sPlan[0].length; j++)
				if(sPlan[i][j].equals("X"))
					assignedSeats++;

		return (assignedSeats == 5 * sPlan[0].length);
	}//end of non smoked
//
	public static boolean isEconomicFull(String[][] sPlan)	
	{
		int i, j;
		
		int assignedSeats = 0;

		for(i = 7; i < 13; i++)
			for(j = 0; j < sPlan[0].length; j++)
				if(sPlan[i][j].equals("X"))
					assignedSeats++;

		return (assignedSeats == 6 * sPlan[0].length);
	}
}