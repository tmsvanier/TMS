package election;
import java.util.*;

public class Election 
{
    static Scanner console=new Scanner(System.in);

    public static void main(String[] args)
    {
     
      String[] candidateName=new String[5];
      int[] votes=new int[5];
      System.out.println("Please enter last names of five\n" +
"candidates the votes received by each of them \n"
              + "(i.e. Smith 45 Yong 55 George 25 Harris 75 Johnson 15)");
                         
      int index;
      for (int i=0;i<candidateName.length;i++)
        {             
            candidateName[i]=console.next();            
            votes[i]=console.nextInt();
        }

        int totalVotes=0;
        for(index=0;index<votes.length;index++)
            totalVotes+=votes[index];
        
        System.out.println("Candidate\tVotes Received\t% of Total Votes");
        
        for(index=0;index<votes.length;index++)
             System.out.println(candidateName[index]+"\t\t" + votes[index]+"\t\t" +String.format("%.2f", (double)votes[index]*100/totalVotes));
       
        System.out.println("\nTotal Votes\t"+totalVotes);

        int winner=largest(votes);
         System.out.println("The Winner of the Election is "+candidateName[winner]);
      
    } 
    
    
    public static int largest (int ...voteList)
    {
        int max, indexlarge=0;        
        if(voteList.length!=0)
        {
            max=voteList[0];
            for(int index=1;index<voteList.length;index++)
            {
                if (max<voteList[index])
                {
                    max=voteList[index];
                    indexlarge=index;
                }
            }
            return indexlarge;
        }
        return 0;
    }
    
}