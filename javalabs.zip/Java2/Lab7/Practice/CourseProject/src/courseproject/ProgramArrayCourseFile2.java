package courseproject;
import java.io.*;
import java.util.*;
public class ProgramArrayCourseFile2 {
    static Scanner inFile;
       public static void main(String[] args)  throws FileNotFoundException{

        inFile=new Scanner(new FileReader("Course.in"));
        inFile.useDelimiter("\t|\r\n"); 
        
        String[] course_no=new String[7];
        String[] course_name=new String[7];

        int[][] enroll = new int[7][2];
        
             
        System.out.print("Reading all columns of the text file course.in \nand filling them into parallel Arrays.\n\n");

        int index=0;
        while(inFile.hasNextLine())
        {
            course_no[index] = inFile.next();
            course_name[index] = inFile.next();
            enroll[index][0] = inFile.nextInt();
            enroll[index][1] = inFile.nextInt();

                         
            index++;
         }
        inFile.close();

        System.out.println("\nOutput of the String One Dim Array of course_no field:");
        System.out.println("Output of the String One Dim Array of course_name field:");
        System.out.println("Output of the Integer Two Dim Array of credits and max_enrl fields:\n");
        
        for (index = 0; index < course_no.length; index++) {
            System.out.println(course_no[index] + ", Course Name: " + 
                    course_name[index] + "\n" +
                    "Credits: " + enroll[index][0] +", Max enrolled: " + enroll[index][1] + "\n");
                    
        }
        
        
       }
}
