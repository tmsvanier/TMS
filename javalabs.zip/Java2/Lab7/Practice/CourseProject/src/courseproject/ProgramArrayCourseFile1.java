package courseproject;
import java.io.*;
import java.util.*;
public class ProgramArrayCourseFile1 {
    static Scanner inFile;
       public static void main(String[] args)  throws FileNotFoundException{

        inFile=new Scanner(new FileReader("Course.in"));
        inFile.useDelimiter("\t|\r\n"); 
        
        String[] course_no=new String[7];
        String course_name, course_noT;
        int credits, max_enrl;
             
        System.out.print("Reading the first column of the text file course.in \nand filling the one dimensional array course_code.\n\n");

        int index=0;
        while(inFile.hasNextLine())
        {
            course_noT = inFile.next();
            course_name = inFile.next();
            credits = inFile.nextInt();
            max_enrl = inFile.nextInt();

            course_no[index]=course_noT;            
                        
            index++;
         }
        inFile.close();

        System.out.println("\nThe components of Array course_code are:");
        for (index = 0; index < course_no.length; index++) {
            System.out.print(course_no[index] + "\n");
        }
        
        
       }
}
