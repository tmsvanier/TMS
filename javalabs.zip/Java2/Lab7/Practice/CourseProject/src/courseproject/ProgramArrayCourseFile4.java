package courseproject;

import java.io.*;
import java.util.*;
public class ProgramArrayCourseFile4 
{

 
    static Scanner inFile;   
    public static void main(String[] args) throws FileNotFoundException 
    {
        inFile=new Scanner(new FileReader("Course.in"));
       
        inFile.useDelimiter("\t|\r\n");
        
        String c_no;
        String c_name;
        int c_max_enrl;
        int c_credits,index;
        
        Course.credits=3;
        Course[] myCourse=new Course[7];
 
        index=0;
        while(inFile.hasNextLine())
            {
                myCourse[index]=new Course();
                c_no=inFile.next();
                myCourse[index].setCourse_no(c_no);
                c_name=inFile.next();
                myCourse[index].setCourse_name(c_name);
                c_credits=inFile.nextInt();
                Course.credits=c_credits;
                c_max_enrl=inFile.nextInt();
                myCourse[index].setMax_enr(c_max_enrl);
                index++;             
            }
        inFile.close();
        
        System.out.println("\nAssigning values to array object referenced "
                + "by my course[] reference objec of type Course calsss\n");
        System.out.print("After setting myCourse[0] componet of the array myCourse[]\n\n");
        
        
        for(int j=0;j<myCourse.length;j++)
        {
            System.out.print("MyCourse["+(j)+"]:\n"
            +"Course Code: "+myCourse[j].getCourse_no()
            +", Course Name: "+myCourse[j].getCourse_name()
            +", Credit: "+Course.credits
            +", Max enrolled: "+myCourse[j].getMax_enr());
            myCourse[j].printCourseInfo();
        }
 
          
    }
    
}


