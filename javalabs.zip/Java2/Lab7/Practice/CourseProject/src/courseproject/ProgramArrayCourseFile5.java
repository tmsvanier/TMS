
package courseproject;

import java.io.*;
import java.util.*;
public class ProgramArrayCourseFile5 
{

   static Scanner inFile;
   static Scanner console;
   
    public static void main(String[] args) throws FileNotFoundException 
    {
        inFile=new Scanner(new FileReader("Course.in"));
       
        inFile.useDelimiter("\t|\r\n");
        
        console=new Scanner (System.in);
        String c_no;
        String c_name;
        int c_max_enrl;
        int c_credits,index;
        double sumFees=0;
        
        Course.credits=3;
        Course[] myCourse=new Course[7];

        index=0;
        while(inFile.hasNextLine())
            {
                myCourse[index]=new Course();
                c_no=inFile.next();
                myCourse[index].setCourse_no(c_no);
                c_name=inFile.next();
                myCourse[index].setCourse_name(c_name);
                c_credits=inFile.nextInt();
                Course.credits=c_credits;
                c_max_enrl=inFile.nextInt();
                myCourse[index].setMax_enr(c_max_enrl);
                index++;             
            }
      inFile.close();

      System.out.print("\nEnter the course code you are looking for: ");
   
      c_no=console.nextLine();

    index=Course.searchCourses(myCourse, c_no);
        
    if(index!=-1)
        System.out.print("\nThe course you  you are looking for is: \n"
                  +"Course Code "+myCourse[index].getCourse_no()
                  +", Course Name: "+myCourse[index].getCourse_name()
                  +", Credit: "+myCourse[index].credits
                  +", Max enrolled: "+myCourse[index].getMax_enr()+"\n");
    else
         System.out.println("\nYour course code does not exist in data base\n\n");
    
    
    Course.printCourses(myCourse);
    
    double totalfees=0;
    
    for(int i=0;i<myCourse.length;i++)
        {
            totalfees+=myCourse[i].calculateTotalFees();
        }    
    System.out.printf("%nThe total fees for the arrray of objects, MyCoursr, is: %.2f%n%n",totalfees);
     
    System.out.print("\nThe largest number of max enroll int the array object myCoursr filled \n"
              + "with datafrom the text file Course.in is: "+Course.largest(myCourse)+"\n");
    
    System.out.print("\n\nThe smallest number of max enroll int the array object myCoursr filled \n"
            + "with datafrom the text file Course.in is: "+
                        Course.smallest(myCourse)+"\n");

  
    }
    
}
