
package courseproject;

public class Course {
    
   
    private String course_no;
    private String course_name;
    private int max_enr;
    public static int credits;
     
    public void printCourseInfo()
        {
            System.out.println("\n The Course Information is: " +course_no+ "//"+ course_name + "//" +max_enr+"\n");

        }
    
    
    Course()
        {
            course_no="";
            course_name="";
            max_enr=0;
            credits=0;

        }

    public String getCourse_no() 
        {
            return course_no;
        }

    public void setCourse_no(String course_no) 
        {
            this.course_no = course_no;
        }

    public String getCourse_name() 
        {
            return course_name;
        }

    public void setCourse_name(String course_name) 
        {
            this.course_name = course_name;
        }

    public int getMax_enr() 
        {
            return max_enr;
        }

    public void setMax_enr(int max_enr) 
        {
            this.max_enr = max_enr;
        }
    
    public static int searchCourses(Course[] wcourse, String wcourse_no) 
        {
            for (int i = 0; i < wcourse.length; i++) 
                {
                    if (wcourse_no.equals(wcourse[i].getCourse_no())) 
                        {
                        return i;
                        }
                }
            return -1;
        }

    public static void printCourses(Course... courseList) 
        {
            for (int i = 0; i < courseList.length; i++) 
                {
                    courseList[i].printCourseInfo();
                }
        }
 
    public double calculateTotalFees() 
        {
            double totalfees = max_enr * 250;
            return totalfees;
        }

    public static double calculateTotalFeesAllCourses(Course... courseList) 
        {
            double totalfees, totalFeesAllCourses;
            totalFeesAllCourses = 0;
            for (int i = 0; i < courseList.length; i++) 
                {
                    totalfees = courseList[i].calculateTotalFees();
                    totalFeesAllCourses = totalFeesAllCourses + totalfees;
                }
            return totalFeesAllCourses;
        }

    public static int largest(Course[] wcourse) {
        int max;
        if (wcourse.length != 0) {
            max = wcourse[0].getMax_enr();
            for (int i = 0; i < wcourse.length; i++) 
                {
                    if (max < wcourse[i].getMax_enr()) 
                        {
                            max = wcourse[i].getMax_enr();
                        }
                }
                return max;
            }
            return 0;
        }
    
    public static int smallest(Course[] wcourse) 
        {
            int min;
            if (wcourse.length != 0) {
                min = wcourse[0].getMax_enr();
                for (int i = 0; i < wcourse.length; i++) 
                    {
                        if (min > wcourse[i].getMax_enr()) 
                            {
                                min = wcourse[i].getMax_enr();
                            }
                    }
                return min;
            }
            return 0;
        }

}