
package courseproject;


public class ProgramArrayCourse1 {


    public static void main(String[] args) {

      
        
        String[] course_code = new String[7];
        
        course_code[0]="MIS 101";
        course_code[1]="MIS 301";
        course_code[2]="MIS 441";
        course_code[3]="CS 155";
        course_code[4]="MIS 451";
        course_code[5]="MIS 551";
        course_code[6]="MIS 651";
    
        
        System.out.print("\n Reading Values From One Fim Array\n\n");
        System.out.print("The components of Array course_code are:\n");
        
        for (int index=0; index<course_code.length; index++)
            System.out.print(course_code[index] + "\n");
    }
    
}
