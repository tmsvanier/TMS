 
package courseproject;

 
public class ProgramArrayCourseFile3 {
    public static void main(String[] args) {
        String c_no;
        String c_name;
        int c_max_enrl;
        int c_credits;
        double sumFees=0;
        
        Course.credits=3;
        Course[] myCourse = new Course[7];
        
        for (int j = 0; j < myCourse.length; j++) {
            myCourse[j]=new Course();
        }
        
        System.out.print("\nAssigning values to array object referenced "
                +"by myCourse[] reference object of type Course class \n");
        
        System.out.print("After setting, myCourse[j] component of the array myCourse[]\n");
        myCourse[0].setCourse_no("MIS_101");
        myCourse[0].setCourse_name("Intro.to.Info.Systems");
        myCourse[0].setMax_enr(140);
        
        myCourse[1].setCourse_no("MIS_301");
        myCourse[1].setCourse_name("Systems.Analysis");
        myCourse[1].setMax_enr(35);
        
        myCourse[2].setCourse_no("MIS_441");
        myCourse[2].setCourse_name("Database.Management");
        myCourse[2].setMax_enr(12);
        
        myCourse[3].setCourse_no("CS_155");
        myCourse[3].setCourse_name("Programming.in.C++");
        myCourse[3].setMax_enr(90);
        
        myCourse[4].setCourse_no("MIS_451");
        myCourse[4].setCourse_name("Web-Based.Systems");
        myCourse[4].setMax_enr(30);
        
        myCourse[5].setCourse_no("MIS_551");
        myCourse[5].setCourse_name("Advanced.Web");
        myCourse[5].setMax_enr(30);
        
        myCourse[6].setCourse_no("MIS_651");
        myCourse[6].setCourse_name("Advanced.Java");
        myCourse[6].setMax_enr(30);
        
        System.out.print("Output the components of the filled array object myCourse[]\n\n");
        
        for (int j = 0; j < myCourse.length; j++) {
            System.out.print("myCourse["+ j + "]:\n"
                    + "Course Code: "+ myCourse[j].getCourse_no()
                    + ", Course Name: "+ myCourse[j].getCourse_name()
                    + ", Credits: "+ Course.credits 
                    + ", Max enrolled: "+ myCourse[j].getMax_enr()+"\n");
            myCourse[j].printCourseInfo();
        }
        
    }
    
}
