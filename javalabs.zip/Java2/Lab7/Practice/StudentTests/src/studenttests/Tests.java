package studenttests;

public class Tests
{
   
    private String firstName, lastName;
    private int[] scores;
    private double average;
    private char grade;

    public Tests()
    {
        firstName = "";
        lastName= "";
        scores=new int[5];
        average=0.00;
        grade ='*';
    }
    public Tests(String firstName, String lastName, int... list)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        scores = list;
        average = calculate_Test_Average();
        grade = calculate_Grade();        
    }

    public String getF_Name() 
    {
        return firstName;
    }

    public void setF_Name(String firstName) 
    {
        this.firstName = firstName;
    }

    public String getL_Name() 
    {
        return lastName;
    }

    public void setL_Name(String lastName)
    {
        this.lastName = lastName;
    }
 
    public int[] getTest_Scores() 
    {
        return scores;
    }
 
     public int getTest_Scores(int item) 
    {
        return scores[item];
    }

    public void setTest_Scores(int... list) 
    {
        for(int index=0;index<scores.length;index++)
        scores[index] = list[index];
    }

    public void setTest_Average(double average) 
    {
        this.average = average;
    }

    public double getTest_Average() 
    {
        
        return average;
    }   

    public char getStudent_Grage()
    {
     
        return grade;
    }


    public void setStudent_Grage(char grade)
    {
        this.grade = grade;
    }

   
    
    public String toString()
      {
          String str="";
          str=String.format("%-13s %-9s ",firstName,lastName);
          for (int score:scores)
          str=str+String.format("%4d \t", score);
          str+=String.format("  %-14.2f %c %n",average,grade);        
          return str;
      }
     public  double calculate_Test_Average()
   {
      double sum=0;
      double average=0;
      
      for(int num:scores)
      {
          sum+=num;
          average=sum/scores.length;
          
      }
      return average;        
   }
     
    public char calculate_Grade()
    {
        if(average>=90)
            return 'A';
        else if(average>=80)
             return 'B';
         if(average>=70)
            return 'C';
        else if(average>=60)
             return 'D';
         else
            return 'F';
    }
         

}
