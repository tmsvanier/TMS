package studenttests;


import java.io.*;
import java.util.*;
public class StudentTests  {   
    
    static Scanner inFile;
    static PrintWriter outFile;
    public static void main(String[] args) throws FileNotFoundException
              
    {
        inFile=new Scanner(new FileReader("Tests.in"));
        outFile=new PrintWriter("Tests.out");
        
        Tests[] students=new Tests[10];
        for(int i=0;i<students.length;i++)
        students[i]=new Tests();
        
        String lastName,firstName;
        int[] scores=new int[5];
        
        int index=0;
        double average=0;
        char ch='*';
        
        System.out.println("First_Name   Last_Name\t  Test1\t  Test2\t  Test3\t  Test4\t  Test5\t  Average\tGrade");
        outFile.println("First_Name   Last_Name\t  Test1\t  Test2\t  Test3\t  Test4\t  Test5\t  Average\tGrade");
        
        while(inFile.hasNextLine())
            {
                firstName=inFile.next();
                lastName=inFile.next(); 
                
                for(int j=0;j<students[index].getTest_Scores().length;j++)
                    scores[j]=inFile.nextInt();              
                students[index].setF_Name(firstName);          
                students[index].setL_Name(lastName);                     
                students[index].setTest_Scores(scores);  
                average=students[index].calculate_Test_Average();
                students[index].setTest_Average(average);
                ch=students[index].calculate_Grade();
                students[index].setStudent_Grage(ch);

                index++;

            } 
        inFile.close();
        for(int i=0;i<students.length;i++)
            {
                System.out.print(students[i].toString());
                outFile.print(students[i].toString());
            }
        
        average=0;
        
        for(int i=0;i<students.length;i++)
        {
            average+= students[i].getTest_Average();

        }
        
        average=(average/students.length);

        System.out.printf("%nClass average = %.2f%n",average);
        outFile.printf("%nClass average = %.2f%n",average);

        outFile.close();
    }
    
   }

