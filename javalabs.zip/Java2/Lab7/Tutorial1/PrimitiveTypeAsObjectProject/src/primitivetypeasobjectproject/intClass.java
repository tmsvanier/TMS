  
package primitivetypeasobjectproject;

 
public class intClass {
    private int x;
    
    public intClass()
    {
        x=0;
    }
    
    public intClass(int num) {
        x = num;
    }
    
    public void setNum(int num)
    {
        x=num;
    }
    
    public int getNum()
    {
        return x;
    }
}
