/*

Why the value referenced by the reference object 
num2 did change after the method call of funcOne(…)?

Because num2 was "set" (b.setNum(30);) in funcOne
and then "get"(num2.getNum()) in the main through the intClass


*/
package primitivetypeasobjectproject;


public class PrimitiveTypeAsObject {


    public static void main(String[] args) {

        int num1;
        
        intClass num2 = new intClass();
        
        char ch;
        StringBuffer str;
        
        num1 = 10;
        num2.setNum(15);
        ch = 'A';
        str = new StringBuffer("Sunny");
        
        System.out.println("Line 9: inside main:"
                + "num1 = " + num1 
                + ", num2 = " + num2.getNum()
                + ", ch = " + ch
                + ", and str = " + str);
        
        funcOne(num1, num2, ch, str);
        
        
        System.out.println("Line 11: After funcOne:"
                + "num1 = " + num1 
                + ", num2 = " + num2.getNum()
                + ", ch = " + ch
                + ", and str = " + str);        
        
          }
    
    public static void funcOne(int a, intClass b, char v, StringBuffer pStr)
    {
        int num, len;
        num = b.getNum();
        a++;
        b.setNum(30);
        v = 'B';
        
        len = pStr.length();
        pStr.append("Warm");
        
        System.out.println("Line 21: inside funcOne: \n"
                + "a = " + a 
                + ", b = " + b.getNum()
                + ", v = " + v
                + ", pStr = " + pStr
                + ", len = " + len
                + ", and num = " + num);            
        
    }
}
