
package arraysasparametersproject;
import java.util.*;

public class ArraysAsParameters {
static final int ARRAY_SIZE = 10;

    public static void main(String[] args) {

        int[] listA = new int[ARRAY_SIZE];
        int[] listB = new int[ARRAY_SIZE];
        
        System.out.print("Line 9: listA elements: ");
        printArray(listA, listA.length);
        System.out.println();
        
        System.out.print("Line 12: enter " + listA.length + " integers: ");
        fillArray(listA, listA.length);
        System.out.println();        
       
        System.out.print("Line 15: After filling listA, the elements are:\n ");
        printArray(listA, listA.length);
        System.out.println();
    }
    
    public static void fillArray(int[] list, int numOfElements)
    {
        Scanner console = new Scanner(System.in);
        for (int index = 0; index < numOfElements; index++)
            list[index] = console.nextInt();
    }   
    
    public static void printArray(int[] list, int numOfElements)
    {
         for (int index = 0; index < numOfElements; index++)
            System.out.print(list[index] + " ");
    }   
    
        
    
}
