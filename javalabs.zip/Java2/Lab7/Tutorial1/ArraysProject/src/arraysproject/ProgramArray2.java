 
package arraysproject;

 
public class ProgramArray2 {

 
    public static void main(String[] args) {
    
        double[] Num = new double[6];
        Num[0] = 5;
        Num[1] = 25;
        Num[2] = 0;
        Num[3] = 12;
        Num[4] = 1;
        Num[5] = 7;
        System.out.println("\nREading values from one Dim.Array\n\n");
        System.out.println("The components of Array Num are:");
        
        for (int index=0; index<Num.length; index++)
        {
            System.out.print(Num[index] + "\t");
        }
    }
    
}
