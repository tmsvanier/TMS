package arraysproject;

public class ProgramArray5 {
 
    public static void main(String[] args) {
    double sumLine=0;
        double[][] Num = {{5, 25, 0, 12, 1, 7}, 
                          {3, 11, 6, 5, 1, 9}, 
                          {6, 64, 45, 8, 96, 3},};
        System.out.println("\nREading values from one Dim.Array\n\n");
        System.out.println("The components of Array Num are:");
        
        for (int row=0; row<Num.length; row++)
        {
            for (int col=0; col<Num[row].length; col++)
                {       
                    System.out.print(Num[row][col] + "\t");
                    sumLine=sumLine+Num[row][col];
                } 
            System.out.printf("The average per Line is: %.2f \n", sumLine/Num[row].length);
        }
    }
    
}
