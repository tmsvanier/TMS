 
package arraysproject;

 
public class ProgramArray4 {

 
    public static void main(String[] args) {
    
        double[][] Num = new double[3][6];
            Num[0][0] = 5;
            Num[0][1] = 25;
            Num[0][2] = 0;
            Num[0][3] = 12;
            Num[0][4] = 1;
            Num[0][5] = 7;
            
            Num[1][0] = 3;
            Num[1][1] = 11;
            Num[1][2] = 6;
            Num[1][3] = 5;
            Num[1][4] = 1;
            Num[1][5] = 9;
            
            Num[2][0] = 6;
            Num[2][1] = 64;
            Num[2][2] = 45;
            Num[2][3] = 8;
            Num[2][4] = 96;
            Num[2][5] = 3;   
        System.out.println("\nREading values from one Dim.Array\n\n");
        System.out.println("The components of Array Num are:");
        
        for (int row=0; row<3; row++)
        {
            for (int col=0; col<6; col++)
                {       
                    System.out.print(Num[row][col] + "\t");
                }   
            System.out.println();
        }
    }
    
}
