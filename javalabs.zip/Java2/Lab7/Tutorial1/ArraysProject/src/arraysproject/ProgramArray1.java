 
package arraysproject;

 
public class ProgramArray1 {

 
    public static void main(String[] args) {
    
        double[] Num = {5, 25, 0, 12, 1, 7};
        System.out.println("\nREading values from one Dim.Array\n\n");
        System.out.println("The components of Array Num are:");
        
        for (int index=0; index<Num.length; index++)
        {
            System.out.print(Num[index] + "\t");
        }
    }
    
}
