
package seqsearchproject;


public class OneDimArrayMethods {
    
    public static int seqSearch(int[] list, int listLength, int searchItem)
    {
        int loc;
        boolean found = false;
        loc = 0;
         
        while (loc< listLength && !found)
            if (list[loc] == searchItem)
                found = true;
            else
                loc++;
        
        if (found)
            return loc;
        else
            return -1;
    }
}
