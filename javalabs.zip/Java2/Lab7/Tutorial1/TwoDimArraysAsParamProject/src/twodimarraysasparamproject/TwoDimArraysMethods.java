package twodimarraysasparamproject;

public class TwoDimArraysMethods {
    
    
    
public static void printMatrix(int[][] matrix)
    {
        for (int row = 0; row<matrix.length;row++)
        {
            for (int col = 0; col<matrix[row].length; col++)
                System.out.printf("%7d", matrix[row][col]);
            System.out.println();

        }
    }
    
public static void sumRows(int[][] matrix)
    {
        int sum;
        
        for (int row = 0; row<matrix.length;row++)
        {
            sum = 0;
            for (int col = 0; col<matrix[row].length; col++)
                sum = sum + matrix[row][col];
            
            System.out.println("The sum of the elements of row " 
            + (row + 1) + " = " + sum + ".");
            

        }
    }
    
    
}
