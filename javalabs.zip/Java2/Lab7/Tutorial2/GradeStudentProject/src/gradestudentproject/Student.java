package gradestudentproject;


public class Student 
{
    
   private int strudent_id;
   private String student_Lname;
   private String student_Fname;
   private double[] student_grade;
   
    public Student()
   {
       strudent_id=0;
       student_Lname="";
       student_Fname="";
       student_grade=new double[5];          
   }

   public int getStudentID()
   {
       return strudent_id;
   }
   public String getStudent_Lname()
   {
       return student_Lname;
   }
    public String getStudent_Fname()
   {
       return student_Fname;
   }
    public double[] getStudent_grade()
    {
              return student_grade;
    }
    public double getStudent_grade(int item)
    {
        
              return student_grade[item];
    }
    

    public void setStudentID( int Id)
    {
        strudent_id=Id;
    }
    public void setStudent_Lname( String lname)
    {
        student_Lname=lname;
    }
    public void setStudent_Fname( String fname)
    {
        student_Fname=fname;
    }
    public void setStudentGrade(double[] item)
    {
        for(int i=0;i<student_grade.length;i++)
        student_grade[i]=item[i];
    }
    
   public Student(int ID,String lname,String fname,double...list)
   {
       strudent_id=ID;
       student_Lname=lname;
       student_Fname=fname;
       student_grade=list;
   
       
   }
   
   public double Calc_Average()
   {
      double sum=0;
      double average=0;
      
      for(double num:student_grade)
      {
          sum+=num;
          average=sum/student_grade.length;
      }
      return average; 
   }       
  
      public String toString()
      {
          String str="";
          str=String.format("%-10s %-10s %-10s%n",strudent_id,student_Lname,student_Fname);
          for (double score:student_grade)
          str=str+String.format("%7.2f%n", score);          
          return str;
          
      }

      
    
}
