package gradestudentproject;

import java.io.*;
import java.util.*;
public class TestGradeStudent
{

    static Scanner inFile;
    static PrintWriter outFile;
    public static void main(String[] args) throws FileNotFoundException
    {

        inFile=new Scanner(new FileReader("Grade.in"));
        outFile=new PrintWriter("Student.out");
        

        Student[] allStudent=new Student[6];
        
        for(int i=0;i<6;i++) allStudent[i]=new Student();
        

        int s_id;String Lnanme,fname;
        double[] infilegrade=new double[5];
        int index=0; 
       System.out.println("Reading Grade from the text file\n\n");
       double average;
     
      while(inFile.hasNextLine())
      {
          average=0;
          s_id=inFile.nextInt();
          Lnanme=inFile.next();
          fname=inFile.next();
          
          for(int j=0;j<allStudent[index].getStudent_grade().length;j++)
           infilegrade[j]=inFile.nextDouble();
    
          allStudent[index].setStudentID(s_id);
          allStudent[index].setStudent_Lname(Lnanme);
          allStudent[index].setStudent_Fname(fname);  
          allStudent[index].setStudentGrade(infilegrade); 

        index++;
      }
      inFile.close();


      int out=0;
      while(out<allStudent.length)
      {
          String str;

          str=(out+1) +" ) Record N: "+(out+1)+", Student Last Name: "+allStudent[out].getStudent_Lname()+
                           ", Student First Name: "+allStudent[out].getStudent_Fname()+"\n";
          for(int j=0;j<allStudent[out].getStudent_grade().length;j++)
            str+="Assignment "+(j+1)+" : "+allStudent[out].getStudent_grade(j)+"\n";
          str+="\n  The Average Score for this student is :"+String.format("%.2f %n", allStudent[out].Calc_Average());

           System.out.println(str);
        
           outFile.print(str);
      out++;
      
    } 

    outFile.close();
    }
    
}
