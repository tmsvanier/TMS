package ForEachArrayProject;


import java.util.*;
public class testForeach 
{


    static Scanner console=new Scanner(System.in);
    public static void main(String[] args) 
    {
        int[] intList=new int[10];
        int number;
        int index;
        double maxNumber;
        
        System.out.println("Line 10: Enter "+intList.length+" integers.\n");
        
        for(index=0;index<intList.length;index++)
        {
            System.out.print("Number "+(index+1)+": ");
            intList[index]=console.nextInt();
        }
            
        System.out.println();
        maxNumber=Largest(intList);
        
        System.out.println("Line 6: The largest number in numList is "+maxNumber);
        
        
 
    }
    public static double Largest(int[] list)
    {
        double max;
        
        
        if(list.length!=0)
        {
            max=list[0];
            for(double num:list)
            {
                if (max<num)
                    max=num;
            }
            return max;
                
        }
        return 0.0;
                
    }
}
