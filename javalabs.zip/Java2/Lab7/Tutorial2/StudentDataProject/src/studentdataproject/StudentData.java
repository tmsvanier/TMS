package studentdataproject;


public class StudentData 
{
 private String firstName;
 private String lastName;
 
 //create an array
 
 private double[] testScores;
 
 private char grade;
 

 public StudentData()
 {
     firstName="";
     lastName="";
     grade='*';
     testScores=new double[5];
     
 }
 
//constructor with parameteres/ the parameter list is of varying length.
 
 public StudentData(String fName,String lName,double ... list)
 {
     firstName=fName;
     lastName=lName;
     grade=courseGrade(list);//calculete and store the grade in grade data member
     testScores=list;
 }
 public char courseGrade(double... list)
 {
     double sum=0;
     double average=0;
     for(double num:list)
         sum+=num;//sum the test scores
     if (list.length!=0)
         average=sum/list.length;
     if (average>=90)
         return 'A';
     else if (average>=80)
         return 'B';
     else if (average>70)
         return 'C';
    else if (average>60)
         return 'D'; 
    else  
         return 'F';
 }
 
 //Method to return a Student's name test scores and grade as a string

 public String toString()
 {
     String str;
     str=String.format("%-10s %-10s",firstName,lastName);
     for (double score:testScores)
         str=str+String.format("%7.2f", score);
     
     str=str+"   "+grade;
     return str;
 }
 
}
