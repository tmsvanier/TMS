package circleproject;

import java.util.*;
public class testCircle
{

  static Scanner console=new Scanner(System.in);
    public static void main(String[] args)
    {
      Circle[] circle =new Circle[5];
      double radius;
      for(int i=0;i<5;i++)
      {
          System.out.print("Enter the radius of circle "+(i+1)+ ": ");
          radius=console.nextDouble();
          circle[i]=new Circle(radius);
          System.out.println();
      }
      for(int i=0;i<5;i++)
          System.out.printf("Circle "+(i+1)+" : "+circle[i]);
    }
    
}
