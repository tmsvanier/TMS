package circleproject;

public class Circle 
{
    private double radius;
    
    public Circle()
    {
        radius=0;
    }
    public Circle(double dRadius)
    {
        radius=dRadius;
    }

    public void SetRadius(double Sradius)
    {
        radius=Sradius;
    }

    public double getRadius()
    {
        return radius;
    }
    
    public String toString()
    {
        return "Radius : "+String.format("%.2f", radius)+" Perimeter : "+String.format("%.2f", perimeter())+ " Area : "+String.format("%.2f", Area())+"\n";
    }
                         
    public double perimeter()
    {
      return (2*Math.PI*radius);
    }
 public double Area()
    {
        return (Math.pow(Math.PI,2)*radius);
    }
    
}
