package arrayofobjectclockproject;

public class testArrayOfObjectClock {

    public static void main(String[] args)
    {
        clock[] arrivalTimeEmp=new clock[100];
        for (int j=0;j<arrivalTimeEmp.length;j++)
            arrivalTimeEmp[j]=new clock();

        arrivalTimeEmp[49].setTime(8, 5, 10);
        
        for(int j=0;j<arrivalTimeEmp.length;j++)
        {
            System.out.print("Employee " + (j+1)+" arrival time: ");
            arrivalTimeEmp[j].printTime();
        }
    }
    
}
