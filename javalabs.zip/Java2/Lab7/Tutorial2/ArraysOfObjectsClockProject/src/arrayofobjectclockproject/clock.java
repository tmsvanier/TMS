package arrayofobjectclockproject;

public class clock 
{
    private int hr;
    private int min;
    private int sec;
      public String toString()
     {
         return "hr: "+hr+" min:"+min+" sec: "+sec;
     }
    
    public clock()
            {
                hr=0;
                min=0;
                sec=0;
            }

   
    public clock(int hours,int minutes, int seconds)
    {
        hr=hours;
        min=minutes;
        sec=seconds;
    }

     public clock(clock temp)
     {
         hr=temp.hr;
         min=temp.min;
         sec=temp.sec;
     }

    public void printTime()
    {

        if (hr<10)
            System.out.print("0");
         System.out.print(hr+ ":");
        if (min<10)
            System.out.print("0");
        System.out.print(min+ ":");
        if (sec<10)
            System.out.print("0");
        System.out.print(sec);
        System.out.println();
        
       
       
    }    

     public void setHours(int ho)
        {
            hr=ho;
        }
     public void setMinutes(int mn)
     {
         min=mn;
     }
    public void setSecond(int sc)
     {
         sec=sc;
     }
    
    public int getHours()           
    {
        return hr;
    }
    public int getMinutes()           
    {
        return min;
    }
    public int getSecond()           
    {
        return sec;
    }

     public boolean equals(clock tempclock)
     {
       return(hr==tempclock.hr && min==tempclock.min && sec==tempclock.sec);  
     }

     public void incrementhour()
     {
         
         if(hr>23&&min>59&&sec>59)
             hr=0;
         else if (min>59&&sec>59)
             hr++;
         else if(hr>23)
                 hr=0;
         else 
             hr++;
     }
     public void incrementminute()
     {
         min++;
         if(hr>23 &&min>59)
         { 
             hr=0;
             min=0;
         }
         else if(min>59)
         { 
             hr++;
             min=0;
         }
     }
     public void incrementsecond()
     {
         sec++;
         if(hr>23&&sec>59&&min>59)
         {hr=0;min=0;sec=0;}
             
         else if(min>59&sec>59)
            {
              min=0;
              sec=0;                     
             }
         else if (sec>59)
         {min++;sec=0;}
             
     }
     public void makecopy(clock tempclock)
     {
         hr=tempclock.hr;
         min=tempclock.min;
         sec=tempclock.sec;
     }
     
    public void setTime(int hours,int minutes,int seconds)
    {
        if(0<=hours && hours<24)
            hr=hours;
        else
            hr=0;
        if(0<=minutes && minutes<60)
            min=minutes;
        else
            min=0;
        if(0<=seconds && seconds<60)
            sec=seconds;
        else
            sec=0;
                    
    }
     
}
