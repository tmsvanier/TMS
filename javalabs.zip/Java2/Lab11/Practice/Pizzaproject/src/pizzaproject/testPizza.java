
package pizzaproject;


public class testPizza {


    public static void main(String[] args) {
        
        PizzaGUI pizza=new PizzaGUI();
    }
    
}
