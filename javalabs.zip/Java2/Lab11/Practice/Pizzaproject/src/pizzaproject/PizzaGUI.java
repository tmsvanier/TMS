
package pizzaproject;

import java.awt.*;
import java.awt.event.*; 
import javax.swing.*;


public class PizzaGUI extends JFrame implements ActionListener, ItemListener {

   JCheckBox TomatoJCB, GreenpapperJCB, Black_OlivesJCB, MuchroomJCB, EctracheeseJCB, PepperoniJCB, sausageJCB;
   JRadioButton SmallRB, MediumRB, LargeRB, ThinRB, Medium_CrustRB, PanRB;
   JTextArea PizzaOrderTA;
   ButtonGroup PizzaSizeBG, pizzaTypeGB ;
   JButton process_selectionJB;
   int count;
   double total_price,price;
   final double topping=1.5;
   String pizType;
   String topp="";
   boolean[] select;
   
   public  PizzaGUI() {
     

       TomatoJCB = new JCheckBox("Tomato");
       GreenpapperJCB = new JCheckBox("Green Pepper");
       Black_OlivesJCB = new JCheckBox("Black Olives");
       MuchroomJCB = new JCheckBox("Mushrooms");
       EctracheeseJCB = new JCheckBox("Extra Cheese");
       PepperoniJCB = new JCheckBox("Pepperoni");
       sausageJCB = new JCheckBox("Sausage");
       
        TomatoJCB.addItemListener(this);
        GreenpapperJCB.addItemListener(this);
        Black_OlivesJCB.addItemListener(this);
        MuchroomJCB.addItemListener(this);
        EctracheeseJCB.addItemListener(this);
        PepperoniJCB.addItemListener(this);
        sausageJCB.addItemListener(this);
        
       SmallRB = new JRadioButton("Small: $6.5");
       MediumRB = new JRadioButton("Meduim: $8.5");
       LargeRB = new JRadioButton("Large: $10.00");
       
       PizzaSizeBG = new ButtonGroup();       
       PizzaSizeBG.add(SmallRB);
       PizzaSizeBG.add(MediumRB);
       PizzaSizeBG.add(LargeRB);
       
       SmallRB.addItemListener(this);
       MediumRB.addItemListener(this);
       LargeRB.addItemListener(this);

       
       ThinRB = new JRadioButton("Thin Crust");
       Medium_CrustRB = new JRadioButton("Meduim Crust");
       PanRB = new JRadioButton("Pan");
       
       pizzaTypeGB = new ButtonGroup();
       pizzaTypeGB.add(ThinRB);
       pizzaTypeGB.add(Medium_CrustRB);
       pizzaTypeGB.add(PanRB);
       
       ThinRB.addItemListener(this);
       Medium_CrustRB.addItemListener(this);
       PanRB.addItemListener(this);


       process_selectionJB = new JButton("Process Selection");
       process_selectionJB.addActionListener(this);
       
       JLabel orderL = new JLabel("Your order:");
       PizzaOrderTA = new JTextArea(500,150);
       
       PizzaOrderTA.setLocation(50,350);
       orderL.setLocation(50,310);
       process_selectionJB.setLocation(250, 300);
       TomatoJCB.setLocation(50, 110);
       GreenpapperJCB.setLocation(50,135);
       Black_OlivesJCB.setLocation(50,160);
       MuchroomJCB.setLocation(50, 185);
       EctracheeseJCB.setLocation(50,210);
       PepperoniJCB.setLocation(50,235);
       sausageJCB.setLocation(50,260);
       
       SmallRB.setLocation(210,110);
       MediumRB.setLocation(210,140);
       LargeRB.setLocation(210,170);
       
       ThinRB.setLocation(370,110);
       Medium_CrustRB.setLocation(370,140);
       PanRB.setLocation(370,170);
 
       PizzaOrderTA.setSize(490, 152);
       process_selectionJB.setSize(160, 35);
       orderL.setSize(100,35);
       TomatoJCB.setSize(120, 25);
       GreenpapperJCB.setSize(120, 25);
       Black_OlivesJCB.setSize(120, 25);
       MuchroomJCB.setSize(120, 25);
       EctracheeseJCB.setSize(120, 25);
       PepperoniJCB.setSize(120, 25);
       sausageJCB.setSize(120, 25);
       SmallRB.setSize(120, 40);
       MediumRB.setSize(120, 40);
       LargeRB.setSize(120, 40);

       ThinRB.setSize(120, 40);
       Medium_CrustRB.setSize(120, 40);
       PanRB.setSize(120, 40);

       
        Container pane = getContentPane();
        pane.setLayout(null);
 
        pane.add(TomatoJCB);
        pane.add(GreenpapperJCB);
        pane.add(Black_OlivesJCB);
        pane.add(MuchroomJCB);
        pane.add(EctracheeseJCB);
        pane.add(PepperoniJCB);
        pane.add(sausageJCB);
        pane.add(SmallRB);
        pane.add(MediumRB);
        pane.add(LargeRB);
        pane.add(ThinRB);
        pane.add(Medium_CrustRB);
        pane.add(PanRB);
        pane.add(process_selectionJB);
        pane.add(orderL);
        pane.add(PizzaOrderTA);

        
        setTitle("Pizza Shop");
        setSize(560,560);
        setVisible(true);
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       count=0;
       total_price=0;
       select = new boolean[7]; 
       for(int i=0 ;i<select.length;i++)
             select[i]=false;
   }

    public void paint(Graphics g)
    {
      super.paint(g);
 
        g.setColor(Color.red);
        g.setFont(new Font("Courier",Font.BOLD,28));
        g.drawString("Welcome to Home Style Pizza Shop",50 , 80);
        g.setFont(new Font("Courier",Font.BOLD,13));
        g.drawString("Each Topping: 1.5$", 60,135);
        g.drawString("Pizza Size", 220,135);
        g.drawString("Pizza Type", 380,135);
        g.setColor(Color.RED);
        g.drawRect(50,115,138,220);
        g.drawRect(210,115,135,160);
        g.drawRect(370,115,135,160);
    }



    @Override
    public void actionPerformed(ActionEvent e)
    {
        PizzaOrderTA.setText("");

        if(price == 6.5)
           PizzaOrderTA.append(calculatePrice("Small"));
        else if(price == 8.5)
           PizzaOrderTA.append(calculatePrice("Medium"));
        if(price == 10.00)
           PizzaOrderTA.append(calculatePrice("Large"));

    }
 

    @Override
    public void itemStateChanged(ItemEvent e)
    {

        if(e.getSource() == TomatoJCB)
         {
             select[0]=false;

             if(e.getStateChange() == ItemEvent.SELECTED)
             {
                 select[0]=true;

             }
              if(e.getStateChange() == ItemEvent.DESELECTED)
             {

                 count--;
                 if(count<0)
                     count=0;
             }
              if(select[0])
                 count++;
          }

        if(e.getSource() == GreenpapperJCB)
         {
             select[1]=false;
             if(e.getStateChange() == ItemEvent.SELECTED)
             {
                select[1]=true;
             }
              if(e.getStateChange() == ItemEvent.DESELECTED)
             {
                 count--;
                 if(count<0)
                     count=0;
             }
              if(select[1])
                 count++;
          }
        if(e.getSource() == Black_OlivesJCB)
         {
           select[2]=false;
             if(e.getStateChange() == ItemEvent.SELECTED)
             {
                 select[2]=true;

              }
              if(e.getStateChange() == ItemEvent.DESELECTED)
             {

                 count--;
                 if(count<0)
                     count=0;
             }
              if(select[2])
                 count++;
          }

        if(e.getSource() == MuchroomJCB)
         {
              select[3]=false;
             if(e.getStateChange() == ItemEvent.SELECTED)
             {
                 select[3]=true;

             }
              if(e.getStateChange() == ItemEvent.DESELECTED)
             {

                 count--;
                 if(count<0)
                     count=0;
             }
              if(select[3])
                 count++;
          }
        if(e.getSource() == EctracheeseJCB)
         {
              select[4]=false;
             if(e.getStateChange() == ItemEvent.SELECTED)
             {
                 select[4]=true;

             }
              if(e.getStateChange() == ItemEvent.DESELECTED)
             {

                 count--;
                 if(count<0)
                     count=0;
             }
              if(select[4])
                 count++;
          }
        if(e.getSource() == PepperoniJCB)
         {
              select[5]=false;
             if(e.getStateChange() == ItemEvent.SELECTED)
             {
                 select[5]=true;
             }
              if(e.getStateChange() == ItemEvent.DESELECTED)
             {
                 count--;
                 if(count<0)
                     count=0;
             }
              if(select[5])
                 count++;
          }
        if(e.getSource() == sausageJCB)
         {
              select[6]=false;
             if(e.getStateChange() == ItemEvent.SELECTED)
             {
                 select[6]=true;
             }
              if(e.getStateChange() == ItemEvent.DESELECTED)
             {
                 count--;
                 if(count<0)
                     count=0;
             }
              if(select[6])
                 count++;
          }
            if(SmallRB.isSelected() == true)
               price=6.5;
             else if (MediumRB.isSelected() == true)
                price=8.5;
            else if (LargeRB.isSelected() == true)
                price=10;


            if(ThinRB.isSelected() == true)
               pizType="Thin Crust";
             else if (Medium_CrustRB.isSelected() == true)
                pizType="Medium Crust";
            else if (PanRB.isSelected() == true)
                pizType="Pan";
   }


    public String calculatePrice(String S)
    {
        for(int i=0;i<select.length;i++)
     {
           if(select[i] == true)
             {
              switch (i)
                {
                case (0):
                    {topp+="Tomato";
                    break;} 
                case (1):
                    {topp+=", green pepper";
                    break;}
                case (2):
                    {topp+=", Black Olives";
                    break;}
                case (3):
                    {topp+=", Muchrooms";
                    break;}
                case (4):
                    { topp+=", extra cheese";
                    break;}
                case (5): 
                    {topp+=", peperoni";
                    break;}
                case (6): 
                    {topp+=", sausage";
                    break;}
                 }
               }
     }
        return"\nPizza Type: " + pizType + "\nPizza Size: " + S + "\nTopping: " + topp + "\nAmount Due: " + String.format("$ %.2f ",(count * topping + price));
    }

}
