
package GUISportBorderLayoutProject;


public class ChildSport extends Sport implements SecondarySport
{
    private double cost_pro;
    Equipment myequipment;

    public ChildSport()
    {
       
        super();
        this.cost_pro =0.00;
         myequipment=new Equipment();
    }

    public ChildSport( String Sname, double Snumberhour, int SnumberWeek,double cost_pro) 
    {
        super(Sname, Snumberhour, SnumberWeek);
        this.cost_pro = cost_pro;
        myequipment=new Equipment();
    }

    public double getCost_pro() {
        return cost_pro;
    }

    public void setCost_pro(double cost_pro) {
        this.cost_pro = cost_pro;
    }
 

    @Override
    public String toString() {
        return super.toString() + "// "  +  cost_pro  + "$\n";
    }

    @Override
    public double CalculateCostTraining()
    {
        return super.CalculateCostTraining() + cost_pro;      //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double SumPro() 
    {
     
       return SecondarySport.costYear1 + SecondarySport.costYear2 ;     //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
