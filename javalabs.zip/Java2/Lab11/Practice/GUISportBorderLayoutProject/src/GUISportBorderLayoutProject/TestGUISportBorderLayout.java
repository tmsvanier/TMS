
package GUISportBorderLayoutProject;
import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;
import java.io.FileReader;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
//import javax.swing.event.*;

public class TestGUISportBorderLayout extends JFrame implements ActionListener, ItemListener, ListSelectionListener  {

    JTextArea jtextareaTF;
    JList jlistTF;
    String[] memberNames = {"Name", "Number Hour per week", "Number_week", "Cost hour"};
    JCheckBox profTraining, inputProftraining;
    BorderLayout borderlayoutmgr;
    JMenuItem output, inputJlist, exit, outputInher, outputPoly, loadingInput, readingArray;
    Scanner inFile;
     ChildSport HockeyPlayer, TennisPlayer;
        Sport[] mySportFile;
        Sport myPlayer ;
        Sport yourPlayer ;
        ChildSport mychildPlayer, yourchildPlayer; 
 
        
                
    public TestGUISportBorderLayout() {
        
 
                HockeyPlayer = new ChildSport("Sydney", 45, 20, 5);
                TennisPlayer = new ChildSport("Raphael", 50, 10, 6);
                
                mychildPlayer = new ChildSport("Fares", 2, 10, 6);
                yourchildPlayer = new ChildSport("Samantha", 2, 18, 7);                  
        
        setTitle("Sport Application Menu");
        Container pane = getContentPane();
        
        setSize(900, 700);
        borderlayoutmgr = new BorderLayout(10, 10);
        pane.setLayout(borderlayoutmgr);
        
        jlistTF = new JList(memberNames);
        jlistTF.setVisibleRowCount(4);
        jlistTF.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        jlistTF.addListSelectionListener(this);
        
        profTraining = new JCheckBox("Professional Training");
        profTraining.addItemListener(this);
        
        inputProftraining = new JCheckBox("Input For Professional Training");
        inputProftraining.addItemListener(this);        
        
        
        
        jtextareaTF = new JTextArea(35, 10);
        pane.add(jlistTF, BorderLayout.NORTH);
        pane.add(jtextareaTF, BorderLayout.CENTER);
        pane.add(profTraining, BorderLayout.WEST);
        pane.add(inputProftraining, BorderLayout.EAST);
        
        
        
        // JMenu        
        JMenuBar menuMB = new JMenuBar();
        JMenu inputD = new JMenu("Input Data GP");
        menuMB.add(inputD);
        
            inputJlist = new JMenuItem("Input from Jlist");
            inputD.add(inputJlist);
            inputJlist.addActionListener(this);      
            
            exit = new JMenuItem("Exit");
            inputD.add(exit);
            exit.addActionListener(this);              
        
        
        JMenu outputParentData = new JMenu("outputParentData");
        menuMB.add(outputParentData);

            output = new JMenuItem("Output");
            outputParentData.add(output);
            output.addActionListener(this);
            
            outputInher = new JMenuItem("Output Inheritance");
            outputParentData.add(outputInher);
            outputInher.addActionListener(this); 
            
        JMenu polymorphism = new JMenu("Polymorphism");
        menuMB.add(polymorphism);        
            outputPoly = new JMenuItem("Output polymorphism");
            polymorphism.add(outputPoly);
            outputPoly.addActionListener(this);
            
        JMenu processing = new JMenu("Processing data files");
        menuMB.add(processing);        
            loadingInput = new JMenuItem("Loading input file into Array");
            processing.add(loadingInput);
            loadingInput.addActionListener(this);   
            
            readingArray = new JMenuItem("Reading loaded Array");
            processing.add(readingArray);
            readingArray.addActionListener(this);              
        
        setJMenuBar(menuMB);
        
     mySportFile=new Sport[5];
     for(int i=0;i<mySportFile.length;i++)
     mySportFile[i]=new Sport();

        
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
    }
    
    
    public void actionPerformed(ActionEvent e) 
    {
 
        if (e.getActionCommand().equals("Exit"))
            {
                System.exit(0);
            }
       JMenuItem mItem = (JMenuItem) e.getSource();
       Sport.costHour = 15;
        
        if(mItem == output)
            {
                myPlayer = new Sport("Bob", 3, 15);
                yourPlayer = new Sport("Irena", 4, 25);                
                String str;
                str = "\n\nName: " + myPlayer.getName() + "\n" +
                        "Number hour of training: " + myPlayer.getNumberHour() + "\n" +
                        "Number Weeks of training: " + myPlayer.getNumberWeek() + "\n" +
                        "Cost of Hour of Training: " + Sport.costHour + "\n" +
                        "Total cost of Training for " + myPlayer.getName() + " is " + myPlayer.CalculateCostTraining() +"$"+
                        "\n\nName: " + yourPlayer.getName() + "\n" +
                        "Number hour of training: " + yourPlayer.getNumberHour() + "\n" +
                        "Number Weeks of training: " + yourPlayer.getNumberWeek() + "\n" +
                        "Cost of Hour of Training: " + Sport.costHour + "\n" +
                        "Total cost of Training for " + yourPlayer.getName() + " is " + yourPlayer.CalculateCostTraining() +"$";                        
                jtextareaTF.append(str);
             
            }
        
        if(mItem == inputJlist)
            {
                String str;
                str =   "\n\nName: " + yourPlayer.getName() + "\n" +
                        "Number hour of training: " + yourPlayer.getNumberHour() + "\n" +
                        "Number Weeks of training: " + yourPlayer.getNumberWeek() + "\n" +
                        "Cost of Hour of Training: " + Sport.costHour + "\n" +
                        "Total cost of Training for " + yourPlayer.getName() + " is " + yourPlayer.CalculateCostTraining() +"$";                        
                jtextareaTF.append(str);
             
            }        
        
        if(mItem == outputInher)
            {

                
                String str;
                str = "\n\nName: " + mychildPlayer.getName() + "\n" +
                        "Number hour of training: " + mychildPlayer.getNumberHour() + "\n" +
                        "Number Weeks of training: " + mychildPlayer.getNumberWeek() + "\n" +
                        "Cost of Hour of Training: " + mychildPlayer.costHour + "\n" +
                        "Total cost of Training for " + mychildPlayer.getName() + " is " + mychildPlayer.CalculateCostTraining() +"$"+
                        "\n\nName: " + yourchildPlayer.getName() + "\n" +
                        "Number hour of training: " + yourchildPlayer.getNumberHour() + "\n" +
                        "Number Weeks of training: " + yourchildPlayer.getNumberWeek() + "\n" +
                        "Cost of Hour of Training: " + yourchildPlayer.costHour + "\n" +
                        "Total cost of Training for " + yourchildPlayer.getName() + " is " + yourchildPlayer.CalculateCostTraining() +"$";                        
                jtextareaTF.append(str);
             
            }     
        
        if(mItem == outputPoly)
            {
            yourPlayer = yourchildPlayer;
            
                String str;
                str = "\n\nPolymorphism: Invoking Subclass method with superclass object reference\n" +
                        "Name: " + yourPlayer.getName() + "\n" +
                        "Number hour of training: " + yourPlayer.getNumberHour() + "\n" +
                        "Number Weeks of training: " + yourPlayer.getNumberWeek() + "\n" +
                        "Cost of Hour of Training: " + yourPlayer.costHour + "\n" +
                        "Total cost of Training for " + yourPlayer.getName() + " is " + yourPlayer.CalculateCostTraining() +"$";
                        
                        jtextareaTF.append(str);
            }   
        
   if(mItem == loadingInput)
            {
            try {
                inFile=new Scanner(new FileReader("Sport.in"));
            } catch (FileNotFoundException ex) {
                System.out.println("The scanner couldn't access Sport.in");
            }
            
            jtextareaTF.setText("");
            jtextareaTF.append("Loading into array in progress...\n");
            while(inFile.hasNextLine()) 
            {                
               for(int index=0;index<mySportFile.length;index++)
               {            
                   mySportFile[index].setName(inFile.next()+" "+inFile.next());
                   mySportFile[index].setNumberHour(inFile.nextDouble());                  
                   mySportFile[index].setNumberWeek(inFile.nextInt());                
                   Sport.costHour=inFile.nextDouble();                
               }
            }
            inFile.close();
            jtextareaTF.append("Loading into Array terminated"); 

            
            }        
   
        if(mItem == readingArray)
            {
            String str4;
             jtextareaTF.append("\nInformation of loaded Array"); 
            for(int index=0;index<mySportFile.length;index++)
            {
   
                str4 = "\n\nName: " + mySportFile[index].getName() + "\n" +
                        "Number hour of training: " + mySportFile[index].getNumberHour() + "\n" +
                        "Number Weeks of training: " + mySportFile[index].getNumberWeek() + "\n" +
                        "Cost of Hour of Training: " + mySportFile[index].costHour + "\n" +
                        "Total cost of Training for " + mySportFile[index].getName() + " is " + mySportFile[index].CalculateCostTraining() +"$";
            
             jtextareaTF.append(str4); 
                    
            }                
             
            }     

    }
    
    public void itemStateChanged(ItemEvent ie) 
    {
        
        if(ie.getSource() == profTraining)
        {
                if(ie.getStateChange() == ItemEvent.SELECTED)
                  {
               
                        Sport.costHour = 15;
                        String str;
                        str = "\n\nName: " + HockeyPlayer.getName() + "\n" +
                                "Number hour of training: " + HockeyPlayer.getNumberHour() + "\n" +
                                "Number Weeks of training: " + HockeyPlayer.getNumberWeek() + "\n" +
                                "Cost of Hour of Training: " + HockeyPlayer.costHour + "\n" +
                                "Total cost of Training for " + HockeyPlayer.getName() + " is " + HockeyPlayer.CalculateCostTraining() +"$"+
                                "\n\nName: " + TennisPlayer.getName() + "\n" +
                                "Number hour of training: " + TennisPlayer.getNumberHour() + "\n" +
                                "Number Weeks of training: " + TennisPlayer.getNumberWeek() + "\n" +
                                "Cost of Hour of Training: " + TennisPlayer.costHour + "\n" +
                                "Total cost of Training for " + TennisPlayer.getName() + " is " + TennisPlayer.CalculateCostTraining() +"$";                        
                        jtextareaTF.append(str);
                  }
                else if(ie.getStateChange() == ItemEvent.DESELECTED)
                  {
                      JOptionPane.showMessageDialog(null, "You have not selected the professional training evaluation!", "Information", JOptionPane.INFORMATION_MESSAGE);
                  }

        }
        
        if(ie.getSource() == inputProftraining)
        {
                if(ie.getStateChange() == ItemEvent.SELECTED)
                  { 
                    TennisPlayer.setName(JOptionPane.showInputDialog(null, "Input your name and press OK", "Input", JOptionPane.QUESTION_MESSAGE));
                    TennisPlayer.setNumberHour(Double.parseDouble(JOptionPane.showInputDialog(null, "Input Number Hour per week and press OK", "Input", JOptionPane.QUESTION_MESSAGE)));
                    TennisPlayer.setNumberWeek(Integer.parseInt(JOptionPane.showInputDialog(null, "Input Number of weeks and press OK", "Input", JOptionPane.QUESTION_MESSAGE)));
                    Sport.costHour = Double.parseDouble(JOptionPane.showInputDialog(null, "Input the cost of Sport training per hour and press OK", "Input", JOptionPane.QUESTION_MESSAGE));
                    TennisPlayer.setCost_pro(Integer.parseInt(JOptionPane.showInputDialog(null, "Input the cosr of Professional training per hour and press OK", "Input", JOptionPane.QUESTION_MESSAGE)));

                        String str2 = "\n\nName: " + TennisPlayer.getName() + "\n" +
                                "Number hour of training: " + TennisPlayer.getNumberHour() + "\n" +
                                "Number Weeks of training: " + TennisPlayer.getNumberWeek() + "\n" +
                                "Cost of Hour of Training: " + TennisPlayer.costHour + "\n" +
                                "Total cost of Training for " + TennisPlayer.getName() + " is " + TennisPlayer.CalculateCostTraining() +"$";                        
                        jtextareaTF.append(str2);                      

                  }

        }        
               
    }
    
    
    public void valueChanged(ListSelectionEvent lse) 
    {
      
        if(jlistTF.getSelectedIndex() == 0)
            {
                yourPlayer.setName(JOptionPane.showInputDialog(null, "Input your name and press OK", "Input", JOptionPane.QUESTION_MESSAGE));
            }
        if(jlistTF.getSelectedIndex() == 1)
            {
                yourPlayer.setNumberHour(Double.parseDouble(JOptionPane.showInputDialog(null, "Input Number Hour per week and press OK", "Input", JOptionPane.QUESTION_MESSAGE)));
            }
        if(jlistTF.getSelectedIndex() == 2)
            {
                yourPlayer.setNumberWeek(Integer.parseInt(JOptionPane.showInputDialog(null, "Input Number of weeks and press OK", "Input", JOptionPane.QUESTION_MESSAGE)));
            }
        if(jlistTF.getSelectedIndex() == 3)
            {                
                Sport.costHour = Double.parseDouble(JOptionPane.showInputDialog(null, "Input the cost of Sport training per hour and press OK", "Input", JOptionPane.QUESTION_MESSAGE));
            }        

    }
    
    public static void main(String[] args) {
        
        TestGUISportBorderLayout border1 = new TestGUISportBorderLayout();

    }
 
}
