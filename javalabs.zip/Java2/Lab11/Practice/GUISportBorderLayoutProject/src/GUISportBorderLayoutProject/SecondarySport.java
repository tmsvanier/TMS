
package GUISportBorderLayoutProject;

public interface  SecondarySport
{
    double costYear1 = 2013;
    double costYear2 = 2014;
    public double SumPro();

}
