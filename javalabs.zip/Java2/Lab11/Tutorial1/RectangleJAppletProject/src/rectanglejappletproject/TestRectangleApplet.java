 
package rectanglejappletproject;
 
import javax.swing.*;
import javax.swing.JApplet.*;
import java.awt.*;
import java.awt.event.*;
public class TestRectangleApplet extends JApplet implements ActionListener {

         JTextField lengthTF, widthTF, areaTF, perimeterTF;

   
        
 public void init() {
        
   //JFrame wframe = new JFrame();
        JLabel lengthL = new JLabel("Enter the Length: ", SwingConstants.RIGHT);
        JLabel widthL = new JLabel("Enter the width: ", SwingConstants.RIGHT);
        JLabel areaL = new JLabel("Area: ", SwingConstants.RIGHT);
        JLabel perimeterL = new JLabel("Perimeter: ", SwingConstants.RIGHT);
        
        lengthTF = new JTextField(10);
        widthTF = new JTextField(10);
        areaTF = new JTextField(10);
        perimeterTF = new JTextField(10);
        
        JButton calculateB = new JButton("Calculate");
        calculateB.addActionListener(this);
        //JButton exitB = new JButton("Exit");
 

//        wframe.setTitle("Area and Perimeter of a Rectangle");
//        
//        wframe.setSize(400, 300);
//        wframe.setVisible(true);
        
        Container pane =  getContentPane();
        pane.setLayout(new GridLayout(5, 2));
        pane.add(lengthL);
        pane.add(lengthTF);
        pane.add(widthL);
        pane.add(widthTF);
        pane.add(areaL);
        pane.add(areaTF);
        pane.add(perimeterL);
        pane.add(perimeterTF);
        pane.add(calculateB);

        
        
    }
 
     
     
          public void actionPerformed(ActionEvent e) {
         
         
              if(e.getActionCommand().equals("Calculate"))
              {
                          double length, width, area, perimeter;
        
                          length = Double.parseDouble(lengthTF.getText());
                          width = Double.parseDouble(widthTF.getText());
                          area = width*length;
                          perimeter = 2*(width+length);
                          areaTF.setText("" + area);
                          perimeterTF.setText("" + perimeter);
        
                }
//              else if(e.getActionCommand().equals("Exit"))
//              {
//                  System.exit(0);
//              }
     
     }
    
}
