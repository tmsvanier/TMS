 
package rectangleproject;

import javax.swing.*;
import java.awt.*;

public class RectangleProgramJFrame1 {

    
    JTextField headingTF;
    
    public RectangleProgramJFrame1() {
        JFrame wframe = new JFrame();
        JLabel headingL = new JLabel("Chat room application: ", SwingConstants.RIGHT);
        
        headingTF = new JTextField(10);
        
        wframe.setTitle("Chat room");
        
        Container pane = wframe.getContentPane();
        
        pane.setLayout(null);
        
        
        headingL.setLocation(50, 20);
        headingTF.setLocation(20, 100);
        headingL.setSize(200, 30);
        headingTF.setSize(200, 30);
        
        pane.add(headingL);
        pane.add(headingTF);
        
        wframe.setSize(550, 350);
        
        wframe.setVisible(true);
        
        
        
        
    }
 
    
    public static void main(String[] args) {
        RectangleProgramJFrame1 RectangleProgram = new RectangleProgramJFrame1();
    
    }
    
}
