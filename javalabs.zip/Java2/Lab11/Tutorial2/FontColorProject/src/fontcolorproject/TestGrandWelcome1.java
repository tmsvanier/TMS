
package fontcolorproject;

import javax.swing.*;
import java.awt.*;

public class TestGrandWelcome1 extends JPanel {

public TestGrandWelcome1() {
    super();
    setBackground(Color.WHITE);
}

public void paintComponent(Graphics g)
{
    super.paintComponent(g);
    
    g.setColor(Color.red);
    g.setFont(new Font("Courier", Font.BOLD, 24));
    g.drawString("Welcome to Hava programming", 30, 30);
    g.drawOval(50, 50, 50, 50);
}
    public static void main(String[] args) {
TestGrandWelcome1 panel = new TestGrandWelcome1();
JFrame application = new JFrame();

application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

application.add(panel);
application.setSize(500,400);
application.setVisible(true);
    
    }
    
}
