package carproject;
 
public class Car {
 
    private int carNumber;
    private String carColor;
    private double carSpeed;
    private boolean carBreakBool;
    public static int carNumberSeats;
    public int numberWheels;
    
    public Car()
    {
        carNumber=0;
        carColor="";
        carSpeed=0.0;
    }    
 
    public Car(int carNumberT, String carColorT, double carSpeedT)
    {
        carNumber=carNumberT;
        carColor=carColorT;
        carSpeed=carSpeedT;
    }
    
    public void setValue(int wcarNumber, String wcarColor, double wcarSpeed)
    {
        carNumber = wcarNumber;
        carColor = wcarColor;
        carSpeed = wcarSpeed;
    }
 
    public double IncreaseSpeed()
    {
        carSpeed = carSpeed * 2;
        System.out.println("\nThe Speed of the Car is doubled: " + carSpeed + "\n");
        return carSpeed;
    }
    
    public double DecreaseSpeed()
    {
        carSpeed = carSpeed - 20;
        System.out.println("\nThe Speed of the Car is decreased by 20km/h: " + carSpeed + "\n");
        return carSpeed;
    }    
    
    public boolean TrueBreak()
    {
        carBreakBool = true;
        return carBreakBool;
    }     
    
    public void printCarInfo()
    {
        System.out.println("The Car information is: " + carNumber + "//"
                + carColor + "//" + carSpeed + "km/h\n");
    }    
    
    public void setCarNumber(int carNumberT)
    {
        carNumber=carNumberT;
    }
    
    public void setCarColor(String carColorT)
    {
        carColor=carColorT;
    }
    
    public void setCarSpeed(int carSpeedT)
    {
        carSpeed=carSpeedT;
    }
    
    public int getCarNumber()
    {
        return carNumber;
    }
    
    public String getCarColor()
    {
        return carColor;
    }
    
    public double getCarSpeed()
    {
        return carSpeed;
    }
 
    public boolean equals(Car otherCar)
    {
        return(carNumber == otherCar.carNumber && carColor.equals(otherCar.carColor) && carSpeed == otherCar.carSpeed);
       
    }
    
    public Car(Car otherCar)
    {
        carNumber = otherCar.carNumber;
        carColor = otherCar.carColor;
        carSpeed = otherCar.carSpeed;
    }
    
    public void makeCopy(Car objectCar)
    {
      carNumber = objectCar.carNumber;
      carColor = objectCar.carColor;
      carSpeed = objectCar.carSpeed; 
    }
    public  static Car transform(Car otherCar)  
    {
        Car trsfCar = new Car();
        
        trsfCar.carNumber = otherCar.carNumber * 2;
        trsfCar.carColor = "Light" + otherCar.carColor;
        trsfCar.carSpeed = otherCar.carSpeed / 2;
        
        return trsfCar;
    }
}