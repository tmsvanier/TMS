package day;
public class Day {

 
	private static final int SUNDAY = 0;
	private static final int MONDAY = 1;
	private static final int TUESDAY = 2;
	private static final int WEDNESDAY = 3;
	private static final int THURSDAY = 4;
	private static final int FRIDAY = 5;
	private static final int SATURDAY = 6;
 
	private int day;

 
	public void setDay(int day) {
		this.day = day;
	}

 
	public void print() {
		System.out.println(this.toString());
	}

 
	public int getDay() {
		return day;
	}

 
	public int getNextDay() {
		return (day + 1) % 7;
	}

	
	public String toString() {
		switch (this.day) {
		case SUNDAY:
			return "Sunday";
		case MONDAY:
			return "Monday";
		case TUESDAY:
			return "Tuesday";
		case WEDNESDAY:
			return "Wednesday";
		case THURSDAY:
			return "Thursday";
		case FRIDAY:
			return "Friday";
		case SATURDAY:
			return "Saturday";
		}
		return "";
	}

 
	public int getPreviousDay() {
		return (day - 1) % 7;
	}

 
	public int addDays(int days) {
		return (day + days) % 7;
	}
 
	public Day() {
		this.day = SUNDAY;
	}

	public Day(int day) {
		this.day = day;
	}

 
	public static void main(String[] args) {

		System.out.println("Test Program For The Day Class");

		System.out.print("\nInitial day: ");
		Day d = new Day(Day.WEDNESDAY);
		d.print();

		System.out.print("\nNext day: ");
		d.setDay(d.getNextDay());
		d.print();

		System.out.print("\nNext day again: ");
		d.setDay(d.getNextDay());
		d.print();

		System.out.println("\nUsing getDay() and toString() methods");
		System.out.println("\tDay Index: " + d.getDay());
		System.out.println("\tDay Name: " + d);

		System.out.print("\nPrevious day: ");
		d.setDay(d.getPreviousDay());
		d.print();

		System.out.print("\nAdd 22 days: ");
		d.setDay(d.addDays(22));
		d.print();

	}
}