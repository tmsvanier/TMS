package lineproject;

public class Line 
{
    double a, b, c, k1, k2, x, y; 

    public Line()
    {
        a = 0;
        b = 0;
        c = 0;
    }
    public Line(double aT,  double bT, double cT)
    {
        a = aT;
        b = bT;
        c = cT;
    }
         
    public void setA(double aT)
    {
        a = aT;
    }
    public void setB(double bT)
    {
        b = bT;
    }
    public void setC(double cT)
    {
        c = cT;
    }    
    public double getA()
    {
        return a;
    }
    public double getB()
    {
        return b;
    }
    public double getC()
    {
        return c;
    }
    
    public double calcSlope1(double a,double b)
    {
        double k1 = - a / b;
        return k1;
    }
    public double calcSlope2(double a,double b)
    {
        double k2 = - a / b;
        return k2;
    }
    
    public static void slopeLine(double k1,double k2)
    {
        if ((k1 != -k2) && (k1 == k2))
        {
           System.out.println("\nThe two Lines are Parallel");  
        }
        else if (k1/k2 == -1)
        {
           System.out.println("\nThe two Lines are Perpendicular");  
        }
        else 
            System.out.println("\nThe two Lines are not Parallel"); 
    }
       
    public static void calcIntersec(double a1,double a2,double b1,double b2,double c1,double c2 )
    {
        double x = (c2*b1 - b2*c1) / (a2*b1 - a1*b2);
        double y = (c1/b1) - (a1/b1) * x;
        System.out.println("The two Lines are not Parallel, the point of Intersection is : " + "(" + x + "," + y + ")");
    }

    public boolean equals(Line otherLine)
    {
        int k = 3;
        return (a == otherLine.a && b == otherLine.b && c == otherLine.c  ||
                a / otherLine.a == b / otherLine.b  &&  a / otherLine.a ==  c / otherLine.c  && b / otherLine.b == c / otherLine.c);
    }
     
    public void printLine()
    {
        System.out.println("\na=" + a + "; b=" + b + "; c=" + c);
    }
 
}
