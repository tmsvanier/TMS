package lineproject;
import java.util.*;

public class TestLine 
{
    public static void main(String[] args)
    {     
        Scanner console = new Scanner(System.in);
        
        System.out.print("Please enter value of A for the first line: ");
        double a = console.nextDouble();
        System.out.print("Please enter value of B for the first line: ");
        double b = console.nextDouble();
        System.out.print("Please enter value of C for the first line: ");
        double c = console.nextDouble();
        
        System.out.print("Please enter value of A for the second line: ");
        double a1 = console.nextDouble();
        System.out.print("Please enter value of B for the second line: ");
        double b1 = console.nextDouble();
        System.out.print("Please enter value of C for the second line: ");
        double c1 = console.nextDouble();        
        
        Line Line1 = new Line(a,b,c);
        Line Line2 = new Line(a1,b1,c1);        
        Line1.printLine();
        Line2.printLine();
        
        double calcSlope1 = Line1.calcSlope1(Line1.getA(),Line1.getB());
        double calcSlope2 = Line2.calcSlope1(Line2.getA(),Line2.getB());
        
        Line.slopeLine(calcSlope1,calcSlope2);
        
        System.out.println("k1=" + calcSlope1 );
        System.out.println("k2=" + calcSlope2 );
        
        if (calcSlope1 != calcSlope2)
        {
        Line.calcIntersec(Line1.getA(), Line2.getA(), Line1.getB(), Line2.getB(), Line1.getC(), Line2.getC());
        }
        
        if (Line1.equals(Line2))
        {
          System.out.println("The two Lines are Equal ");   
        }
        else
          System.out.println("The two Lines are not Equal "); 
          System.out.println(); 
    }
    
}
