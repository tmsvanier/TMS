package personproject;
public class TestPerson {

    public static void main(String[] args) 
    {
         Person otherPerson1 = new Person(); 
         Person otherPerson2 = new Person();

         otherPerson1.setName("Ashley","J","Blair");
         
         System.out.println("Person1: " + otherPerson1.toString());
         
         otherPerson2.setName("Donald","M","Jackson");
         
         System.out.println("Person2: " + otherPerson2.toString());
 
         
         if (otherPerson1.equals(otherPerson2))
         {
            System.out.println("After checking: True, the names are the same.");   
         }
         else
            System.out.println("After checking: False, the names are not the same."); 
         
         System.out.println(); 
         
         otherPerson2.makeCopy(otherPerson1);
         
         if (otherPerson1.equals(otherPerson2))
         {
            System.out.println("After making Copy the names are the same.");   
         }
         else
         {
             System.out.println("False, The names are not the same.");
         }

         System.out.println(" Person1: " + otherPerson1.toString());
         System.out.println(" Person2: " + otherPerson2.toString());
         
         Person otherP3 = new Person();
         
         otherP3.setName("Sandy","Bad","Smith");
         otherPerson1 = otherP3.getCopy();
         
         System.out.println(); 
         System.out.println("After applying method getCopy of the Person3, Person1 is: " + otherPerson1.toString());
         System.out.println(); 
    }
    
}
