
package personproject;


public class Person 
{
    String firstName, lastName, middleName;
 
    
    public Person()
    {
        firstName = ""; lastName = ""; middleName = "";
    }
    public Person(String first, String last, String middle)
    {
        setName(first, last, middle);
    }
     
    public String toString()
    {
        return (firstName + " " + middleName + " " + lastName);
    }
    
    public void setName(String first, String middle, String last)
    {
        firstName = first;
        lastName = last;
        middleName = middle;
    }
        
    public void setLastName( String last)
    {
        lastName = last;
    } 
    public void setFirstName(String first)
    {
        firstName = first;
    } 
    public void setMiddleName(String middle)
    {
        middleName = middle;    
    }
    public String getLastName( String last)
    {   
        return lastName ;
    } 
    public String getFirstName(String first)
    {
        return firstName ;
    } 
    public String getMiddleName(String middle)
    {
        return middleName ;
    } 
     
    public boolean equalsLast(String otherLastName)
    {
         return (lastName == otherLastName);
    }
    public boolean equalsFirst(String otherFirstName)
    {
         return (firstName == otherFirstName);
    } 
    public boolean equalsMiddle (String otherMiddleName)
    {
        return (middleName == otherMiddleName);
    } 
     
     
    public boolean equals (Person otherPerson)
    {
        return (lastName == otherPerson.lastName && firstName == otherPerson.firstName&& middleName == otherPerson.middleName);
    }
    
    public void makeCopy(Person otherPerson)
    {
           lastName = otherPerson.lastName;
           firstName = otherPerson.firstName;        
           middleName = otherPerson.middleName;        
    } 
    public Person getCopy() 
    {        
            Person testPerson = new Person(); 
            testPerson.lastName = lastName;
            testPerson.firstName = firstName;        
            testPerson.middleName = middleName; 
            return testPerson; 
    }
}
