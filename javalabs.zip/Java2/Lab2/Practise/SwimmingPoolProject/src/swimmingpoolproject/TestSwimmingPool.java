package swimmingpoolproject;
import java.util.Scanner;

public class TestSwimmingPool 
{
    public static void main(String[] args)
    {
        Scanner console = new Scanner(System.in);
 
        System.out.print("Please enter the length of the pool: "); 
        int length=console.nextInt();
        System.out.print("Please enter the width of the pool: "); 
        int width=console.nextInt();        
        System.out.print("Please enter the depth of the pool: "); 
        int depth=console.nextInt(); 
        System.out.print("Please enter the rate (in gallons per minute) at which the water is filling the pool: "); 
        double rateFill=console.nextDouble();         
        System.out.print("Please enter the rate (in gallons per minute) at which the water is draining from the pool: "); 
        double rateDrain=console.nextDouble();  
        System.out.print("Please enter the amount of time for filling/draining: "); 
        int time=console.nextInt();          
        
        Pool testPool = new Pool(length, width, depth, rateFill, rateDrain, time);
        
        testPool.CalculateAmountWater();
        System.out.println("\n\nTotal amount of water: " + testPool.CalculateAmountWater()); 
        System.out.println("Time to fill the Pool:(in minutes) " + testPool.CalculateTimeFill()); 
        System.out.println("Time to empty the Pool:(in minutes) " + testPool.CalculateTimeEmpty()); 
        System.out.println("Amount of water to FILL: " + testPool.CalculateFillTime());
        System.out.println("Amount of water to DRAIN: " + testPool.CalculateDrainTime()); 

    }
    
}
