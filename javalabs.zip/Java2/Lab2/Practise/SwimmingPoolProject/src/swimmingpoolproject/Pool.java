package swimmingpoolproject;

public class Pool 
{
    int length, width, depth, time; 
    double rateFill, rateDrain, AmW, AmW1;

    public Pool(int lengthT, int widthT, int depthT, double rateFillT, double rateDrainT, int timeT)
    {
        length = lengthT; width = widthT; depth = depthT; rateFill = rateFillT; rateDrain = rateDrainT; time = timeT;
    }
    
    public double CalculateAmountWater()
    {
        double AmountWater = length * width * depth;
        return AmountWater;
    }
    public double CalculateTimeFill()
    {
        double TimeIn = CalculateAmountWater() / rateFill;
        return TimeIn;
    }
    public double CalculateTimeEmpty()
    {
        double TimeEm = CalculateAmountWater() / rateDrain;
        return TimeEm;
    } 
    public double CalculateFillTime()
    {
        double FillTime = time * rateFill;
        return FillTime;
    }
        public double CalculateDrainTime()
    {
        double DrainTime = time * rateDrain;
        return DrainTime;
    }
    
}