package dayproject;

public class Day
{
     static final int MONDAY = 0;
     static final int TUESDAY = 1;
     static final int WEDNESDAY = 2;
     static final int THURSDAY = 3;
     static final int FRIDAY = 4;
     static final int SATURDAY = 5;
     static final int SUNDAY = 6;
     
public static int day;
//public static int days;

public void setDay(int day) 
{
    this.day = day;
}


public void print() 
{
    System.out.println(this.toString());
}


public int getDay() 
{
    return day;
}


public int getNextDay() 
{
    return (day + 1) ;
}
public int addDays1(int days) 
{
    return (day + days);
    
    
}

public String toString() 
{
    switch (day) 
    {
    case 0:
        return "Monday";
    case 1:
        return "Tuesday";
    case 2:
        return "Wednesday";
    case 3:
        return "Thursday";
    case 4:
        return "Friday";
    case 5:
        return "Saturday";
    case 6:
        return "Sunday";
    case 7:
        return "Monday";        
    }
    return "0";
}




public int getPreviousDay() 
{
    switch (day)
    {
        case 0:
            return (day + 6);
        case 1:
            return (day - 1);
        case 2:
            return (day - 1);   
        case 3:
            return (day - 1);   
        case 4:
            return (day - 1);
        case 5:
            return (day - 1);
        case 6:
            return (day - 1); 
           
    }
         return (day - 1) ;  

}
 
 
public int addDays(int days) 
{
    return (day + days +7) % 7;
}
 

public Day() 
{
    this.day = MONDAY;
}

public Day(int day)
{
    this.day = day;
}
public static void menu1()
{
    System.out.println("Please Select the Day :");
    System.out.println("0: Monday");
    System.out.println("1: Tuesday");
    System.out.println("2: Wednesday");
    System.out.println("3: Thursday");
    System.out.println("4: Friday");
    System.out.println("5: Saturday");
    System.out.println("6: Sunday");
   
}

public static void menu2()
{
    System.out.println("Enter: ");
    System.out.println("1: To Enter weekday.");
    System.out.println("2: For Test Data.");
    
}

}