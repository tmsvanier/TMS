package dayproject;
import java.util.*;

public class TestDay {

    public static void main(String[] args)
    {
    Scanner console = new Scanner(System.in);

    Day d1 = new Day(Day.MONDAY);
    int choice;
    
       
        Day.menu2();
        choice = console.nextInt();
        System.out.println();

        switch (choice)
        {
        case 1:
                    
                Day.menu1();
                Day.day = console.nextInt();
                System.out.println();

                System.out.print("The day you selected as your starting day is: ");
                d1.print();
                System.out.println();

                System.out.print("The next day to your selected day is: ");
                d1.setDay(d1.getNextDay());
                d1.print();
                System.out.println();

                System.out.print("The previous day to your selected day is: ");
                d1.setDay(d1.getPreviousDay());
                d1.setDay(d1.getPreviousDay());
                d1.print();
                System.out.println();

                System.out.print("How many days would you like to add? ");

                int days = console.nextInt();
               
                System.out.print("\nAdding " + days + " day(s) makes your new day: ");
                d1.addDays(days);
                
                Day.day = Day.day + days;
//                d1.print();
 System.out.println(d1.addDays(days));
           
            break;

        case 2:
            System.out.println("Test Data For Day Class");
            Day.day = 1;
            System.out.print("\nInitial day: ");
            d1 = new Day(Day.MONDAY);
            d1.print();

            System.out.print("\nNext day: ");
            Day.day = 0;
            d1.setDay(d1.getNextDay());
            d1.print();

            System.out.print("\nAdd 3 Days: ");
            Day.day = 0;
            d1.setDay(d1.addDays1(3));
            d1.print();

            System.out.print("\nPrevious day: ");
            Day.day = 0;
            d1.setDay(d1.getPreviousDay());
            d1.print();

            System.out.print("\nAdd 5 days: ");
            Day.day = 0;
            d1.setDay(d1.addDays1(5));
            d1.print();
            System.out.println("\n\n");

            break;
                   
        }

    
      }


}
    

